#include <stdio.h> 
#include <math.h>

//function declarations
void header ();
void ReadIn ();
void clear (); 
void solve ();
void printX ();

//Instance Variables
float a,b,c,xone,xtwo; 

//main method
int main(){
	header();
	ReadIn();
   	clear();
	header();
	solve();
	printX();
}

//Function returns header at the top of the page
void header (){
	printf("\n\tDavid Pearson 1725412\n\t5CS021\n\tNumerical Methods in C\n\t1.2 Quadratic Equation\n\n");
}

//Function reads in the two sets of co-ordinates
void ReadIn (){
	printf("\tEnter the value for A = ");
	scanf("%f", &a);
	printf("\tEnter the value for  B = ");
	scanf("%f", &b);
	printf("\tEnter the  value for C = ");
	scanf("%f", &c);
}

//Function to clear the screen
void clear(){
    printf("\033[H\033[J");
}

//Function to solve x
void solve(){
	xone = ((b*-1) + sqrt((b*b)-(4*a*c)))/(2*a);
	xtwo = ((b*-1) - sqrt((b*b)-(4*a*c)))/(2*a);
}

//function to print the values of X
void printX(){
	printf("\tX = %.1f  &  %.1f\n", xone,xtwo);
}

