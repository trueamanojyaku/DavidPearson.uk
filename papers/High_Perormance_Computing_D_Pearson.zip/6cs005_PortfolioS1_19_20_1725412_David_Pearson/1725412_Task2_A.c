//David Pearson 1725412

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>

int time_difference(struct timespec *start,
                    struct timespec *finish,
                    long long int *difference);

int main() {

int N = 700;
int P = 700;
int M = 700;

int A[N][P], B[P][M], C[N][M], E[N][M];

//Create Matrix A
for (int x = 0; x < N; x++){
    for (int y = 0; y < M; y++){
        int r = rand() % 100 + 1;
        A[x][y] = r;
    }
}

//Create Matrix B
for (int x = 0; x < P; x++){
    for (int y = 0; y < M; y++){
        int r = rand() % 100 + 1;
        B[x][y] = r;
    }
}

printf("\033[H\033[J"); 
printf("\n\tDavid Pearson 1725412"); 
printf("\n\t6CS005\n\tHigh Performance Computing"); 
printf("\n\tMatrix Multiplication\n"); 
printf("\n =================================================\n"); 
struct timespec start,finish;
long long int time_elapsed;
clock_gettime(CLOCK_MONOTONIC, &start);
printf("||  Started calculation using original code      ||\n");
//Calculate Matrix C
for (int i = 0; i < N; i++) {
        for (int j = 0; j < M; j++) {
                C[i][j] = 0;
                for (int k = 0; k < P; k++) {
                        C[i][j] = C[i][j] + A[i][k] * B[k][j];
                }
        }
}
clock_gettime(CLOCK_MONOTONIC, &finish); 
time_difference(&start, &finish, &time_elapsed);
printf("||  Finished calculation                         ||\n");
printf("||  Time taken to complete was = %0.2lf seconds    ||\n",(time_elapsed/1.0e9));
printf(" =================================================");

struct timespec start1,finish1;
long long int time_elapsed1;
clock_gettime(CLOCK_MONOTONIC, &start1);
printf("\n||  Started calculation using modified code      ||\n");
//Calculate Matrix E 
for (int k = 0; k < N; k++) {
        for (int i = 0; i < M; i++) {
                for (int j = 0; j < P; j++) {
                        E[i][j] += A[i][k] * B[k][j];
                }
        }
}
clock_gettime(CLOCK_MONOTONIC, &finish1); 
time_difference(&start1, &finish1, &time_elapsed1); 
printf("||  Finished calculation                         ||\n");
printf("||  Time taken to complete was = %0.2lf seconds    ||\n",(time_elapsed1/1.0e9));
printf(" =================================================");
float D = (time_elapsed/1.0e9)-(time_elapsed1/1.0e9);
printf("\n||  This is a difference of %0.4f seconds       ||\n",D);
printf("||  Representing an increase/loss of %0.2f%%      ||\n",((D/(time_elapsed/1.0e9))*100));
printf(" =================================================\n");
}

//function for time differnce
int time_difference(struct timespec *start,
                    struct timespec *finish,
                    long long int *difference){

long long int ds = finish->tv_sec - start->tv_sec;
long long int dn = finish->tv_nsec - start->tv_nsec;

if(dn < 0){
    ds--;
    dn += 1000000000;
    }
    *difference = ds * 1000000000 + dn;
    return !(*difference > 0);
}