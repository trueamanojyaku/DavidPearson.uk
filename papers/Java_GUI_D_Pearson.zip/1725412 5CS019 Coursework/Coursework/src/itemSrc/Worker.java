package itemSrc;

/**
 * a Worker object is responsible for processing orders in the warehouse
 * @author David Pearson
 */

public class Worker   {
	/**
	 * The attributes of a worker are:
	 * CustomerQueue - a linkedList of customers to be processed
	 * RucksackMap - a TreeMap containing rucksack objects to be processed 
	 * workerName - The name assigned to the worker
	 * currentCust - the customer currently being processed
	 * state - is the worker open or closed
	 * finished - has the worker finished all parcel processing
	 */
	private CustomerQueue queue;
	private RucksackMap allRucksacks;
	private String workerName;
	private Customer currentCust;
	private boolean state = true;
	private boolean finished = false;
	
	
	/**
	 * The constructor for a worker object
	 * @param queue is the list of customers to be processed
	 * @param allRucksacks is the list of rucksacks to be processed
	 * @param numWorker the workers ID number
	 * @param state is set to true by default
	 * @param Finished is set to false by default
	 */
    public Worker(CustomerQueue queue,RucksackMap allRucksacks,String workerName) {
    	 this.queue = queue;
    	 this.allRucksacks = allRucksacks;
    	 this.workerName = workerName;
	}
    
	/**
	 * This method returns the current customer, i.e. the customer object assigned to
	 * the worker
	 * 
	 * @return a customer object set to the worker
	 */
    public Customer getCurrentCust() {
    	return currentCust;
    }
    
    /**
     * This method will tell you the name of the worker
     * 
     * @return the name of current worker
     */
    public String getName() {
    	 return workerName;
    }
    
	/**
	 * This method will return the state of the worker
	 * 
	 * @return true or false depending on whether the worker is open or closed
	 */
	public boolean getState() {
		return state;
	}
	
	/**
	 * This method when called will toggle the state of the worker
	 */
	public void changeState() {
		state = !state; 
	}
	
	/**
	 * This method returns if the worker is finished or not
	 * 
	 * @return true if finished or false if not.
	 */
	
	public boolean getFinished() { 
		return finished; 
	}


    /**
     * This method looks to the LinkedList queue of customers then
     * polls the first one and removes it from the list
     * 
     * @return the next customer in the Queue.
     */
	public  Customer getNext() {	
		Customer c = queue.getNext();
		return c;
	}
	
	/**
	 * this method is for processing one customer's order
	 * it outputs a string used by the GUI
	 * It sets the workers customer by calling getNext on the queue
	 * It then checks to see if it actually has a customer
	 * It then sets the variable Rid to the customers Rid
	 * it then uses this to set variable p to the corresponding rucksack
	 * It then sets p to collected
	 * It then generates a String for the GUI
	 * it finally checks to see if there are any orders remaining 
	 * if there are none then it sets the worker to finished
	 * 
	 */
	public String processOneCustomer() {
		String output;
		currentCust = this.getNext() ;
		if (currentCust != null) {
			String rid = currentCust.getrId();
			Rucksack p = allRucksacks.findRucksack(rid);
			allRucksacks.setCollected(p);
			output = this.getName() + " has processed Customer " + currentCust.getName() + " with Rucksack ID = " + rid;
		    if (allRucksacks.allGone() ) {
				finished = true;
				output = "No Orders Left to Process";
			}
		}
		else   
		{
			finished = true;
			output = "No Orders Left to Process";
		}
		return output;
	}
}
