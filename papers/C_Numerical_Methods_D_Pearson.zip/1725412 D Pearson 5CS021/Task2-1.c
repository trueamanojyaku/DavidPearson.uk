#include <stdio.h> 
#include <stdlib.h>
#include <time.h>
#include <pthread.h>

//function declarations
void header ();
void clear ();
int fileLength(char *filename);
int check_prime(long a);
void createNumberList(char *filename, long *list, int length);
void outputNumbers(char *filename,long *list, int length);
void *tSolve (void *arg);

//Structure definition
struct block {
	long start;
	long end;
};

//Variable Declaration
int threads = 0;
long *inList = NULL;
long *outList = NULL; 

int main(int argc, char *argv[] ){
	clock_t begin = clock();
	clear ();
	header ();
	printf("\n\tEnter number of threads = ");
	scanf("%d",&threads);
	int A = fileLength(argv[1]);
	printf("\n\tThe length of the file is %d\n", A);
	inList = malloc(sizeof(long)*A);
	outList = malloc(sizeof(long)*A);
	createNumberList(argv[1],inList, A);
	struct block tpoints[threads];
	long chunk = A / threads;
	long start = 0;
	for (int c = 0; c<(threads-1); c++) {
		tpoints[c].start = start;
		tpoints[c].end = start + chunk;
		start += chunk;
	}	
	tpoints[threads-1].start = (tpoints[threads-2].end);
	tpoints[threads-1].end = A;
	for (int c = 0; c <threads; c++){
	printf("\n\tthread %d starts at %ld ends at %ld",c,tpoints[c].start,tpoints[c].end);
	}
	pthread_t tIDs[threads];
	pthread_attr_t attr[threads];
	for (int c = 0; c < threads; c++){
		pthread_attr_init(&attr[c]);
	}
	for (int c = 0; c < threads; c++){
		pthread_create(&tIDs[c],&attr[c],tSolve,&tpoints[c]);
	}
	for (int c = 0; c < threads; c++){
		pthread_join(tIDs[c],NULL);
	}	
	outputNumbers(argv[2],outList,A);
	int B = fileLength(argv[2]);
	printf("\n\tThe length of the prime number file is %d\n", B);
	clock_t end = clock();
	double time_spent = (double)(end - begin) / CLOCKS_PER_SEC;
	printf("\n\ttime taken = %0.4f seconds\n",time_spent);
}

//Function returns header at the top of the page
void header () {
	printf("\n\tDavid Pearson 1725412\n\t5CS021\n\tNumerical Methods in C\n\t2.1 Prime Numbers\n\n");
}

//Function to clear the screen
void clear() {
    printf("\033[H\033[J");
}


//Function to get the length of the file
int fileLength(char *filename){
	int length = 0;
	FILE *myFile;
	myFile = fopen(filename, "r");
	while(!feof(myFile)) {	
  		int ch = fgetc(myFile);
  			if(ch == '\n'){
    			length++;
  			}
	}
	fclose(myFile);
	return length;
}

//Function to check if input is prime
int check_prime(long a){
	int c;
	if (a < 2) {
		return 0;
	}
	for ( c = 2 ; c <= a - 1 ; c++ ) { 
		if ( a%c == 0 ){
			return 0;
		}
	}
	return 1;
}

//Function to create a list of numbers from the file
void createNumberList(char *filename, long *list, int length) {
	FILE *myFile;
	myFile = fopen(filename, "r");
	for (int c = 0; c < length; c++) {
		fscanf(myFile, "%ld\n", &list[c]);
	}
	fclose(myFile);
}


//Function to write out the file
void outputNumbers(char *filename,long *list, int length){
	FILE *myFile;
	myFile = fopen(filename, "w");
	for (int c = 0; c < length; c++) {
			if (list[c] != -1) {		
			fprintf(myFile,"%ld\n",list[c]);	
		}
	}
	fclose(myFile);	
}

//Thread based solve function
void *tSolve (void *arg){
	struct block *tpoints = (struct block*) arg;
	for (long s = tpoints->start; s < tpoints->end; s++) {
		if (check_prime(inList[s]) == 1){
			outList[s] = inList[s];
			//printf("\t%ld was prime \n",inList[s]);	
		} else{
		outList[s] = -1;
		//printf("\t%ld was not prime \n",inList[s]);	
		}
	}
	pthread_exit(0);
}
