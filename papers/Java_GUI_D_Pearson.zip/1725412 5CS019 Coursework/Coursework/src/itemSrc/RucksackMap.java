package itemSrc;

import java.util.TreeMap;

/**
 * This is the RucksackMap object class
 * it creates a TreeMap for Rucksack Objects
 * and allows management of them
 *
 * @author David Pearson
 *
 */
public class RucksackMap
{
	/**
	 * This defines the structure of the TreeMap,
	 * with a String for the key and a Rucksack Object
	 * for a value
	 */
    private TreeMap <String,Rucksack> allRucksacks;

    /**
     * This is a constructor for a TreeMap that will hold
     * rucksack objects
     */
    public RucksackMap() {
    	allRucksacks = new TreeMap <String,Rucksack>();
    }

    /**
     * This method is used to add a rucksack object
     * to the TreeMap
     * @param details is a rucksack object
     */
    public void addDetails(Rucksack details) {
    	allRucksacks.put(details.getId(), details);
    }

    /**
     * This method returns if the TreeMap contains any
     * rucksack objects in it
     * @return True if there are Rucksacks in the TreeMap, False if there are non
     */
    public boolean hasRucksack() {
    	return !allRucksacks.isEmpty();
    }

    /**
     * This method returns the number of entries in the
     * TreeMap
     * @return how many Rucksack objects are in the TreeMap
     */
    public int getNumberOfEntries() {
    	return allRucksacks.size();
    }


    /**
     * This method iterates through all of the Rucksack objects in
     * the TreeMap. For each Rucksack Object it calls the isCollected Method
     *
     * @return False if there are any rucksacks that return false when isCollected
     * is called and True if all Rucksacks have returned True when isCollected is called
     */
    public boolean allGone () {
    	for (Rucksack r : allRucksacks.values()) {
    		if (!r.isCollected()) {
    			return false;
    		}
    	}
    	return true;
    }
    /**
     * This method generates a string of rucksack object details
     * per line of all of the rucksack objects in the TreeMap
     * @return the generated String
     */
    public String listDetails() {
    	StringBuffer b = new StringBuffer();
    	for (Rucksack r : allRucksacks.values()) {
    		b.append(r + "\n");
    	}
        return b.toString();
    }

    /**
     * This method takes in a rucksack object P and
     * then sets the collected state of the object to
     * true
     *
     * @param p is the rucksack object
     */
    public void setCollected(Rucksack p) {
    	p.setCollected();
    }

    /**
     * This method iterates through the rucksack objects in the TreeMap
     * then checks if the rucksack has returned false on the isCollected call
     * if false, then the rucksack details are appended to the output string
     *
     * @return all rucksack object details, for rucksacks that have not been
     * collected, 1 tiem per line
     */
    public String listUncollected() {
    	StringBuffer b = new StringBuffer();
    	for (Rucksack r : allRucksacks.values()) {
    		if (!r.isCollected()) {
    			b.append(r + "/n");
    		}
    	}
        return  b.toString();
    }

    /**
     * This method takes in a String to represent the Rucksack object ID
     * it will then search the TreeMap for the corresponding Key ID and return the
     * object if the item id found
     * @param id that you are searching for
     * @return the rucksack object with the matching ID, if not found then null
     */
    public Rucksack findRucksack(String id) {
    	return allRucksacks.getOrDefault(id,null);
    }

}
