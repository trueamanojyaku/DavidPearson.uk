#include <stdio.h> 
#include <math.h>

//function declarations
void header ();
void ReadIn ();
void CoordinateOut();
void clear (); 
void findValues ();
void formulaOut();

//Instance Variables
float xone, xtwo, yone, ytwo, m, c;

//main method
int main(){
	header();
	ReadIn();
    clear();
	header();
	CoordinateOut();
	findValues();
	formulaOut();
}

//Function returns header at the top of the page
void header (){
	printf("\n\tDavid Pearson 1725412\n\t5CS021\n\tNumerical Methods in C\n\t1.1 Y=MX+C\n\n");
}

//Function reads in the two sets of co-ordinates
void ReadIn (){
	printf("\tEnter the first value of X = ");
	scanf("%f", &xone);
	printf("\tEnter the first value of Y = ");
	scanf("%f", &yone);
	printf("\tEnter the first value of X = ");
	scanf("%f", &xtwo);
	printf("\tEnter the first value of Y = ");
	scanf("%f", &ytwo);
}

//Function returns co-ordinates entered on two lines
void CoordinateOut(){
    printf("\n\tYou have entered the co-ordinates");
    printf("\n\tFirst Set = (X %.1f, Y %.1f)\n\tSecond Set = (X %.1f, Y %.1f)\n\n", xone, yone, xtwo, ytwo);
}

//Function to clear the screen
void clear(){
    printf("\033[H\033[J");
}

//Function to find the slope or gradient M
void findValues(){
    m = (ytwo-yone)/(xtwo-xone);
    printf("\n\t the slope (M) is %.1f\n" , m);
	c = yone-(m*xone);
    printf("\n\t the constant (C) is %.1f\n" , c);	
}

//Function to print out formula
void formulaOut(){
    printf("\n\t Y = %.1fX + %.1f\n", m, c);
}

