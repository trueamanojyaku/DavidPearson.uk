#include <stdio.h> 
#include <math.h>

//function declarations
void Header ();
void ReadIn ();
void Clear (); 
void FirstRoot();
void Solve();
void PrintRoots();

//Instance Variables
double a,b,c,d,R1,R2,R3,n,p;
double lastGuess = 1;
double G = 0;

//creating a boolean type
typedef int bool;
#define true 1
#define false 0

//main method
int main(){
	Header();
	ReadIn();
    Clear();
	Header();
	FirstRoot();	
	Solve();
	PrintRoots();
}

//Function returns header at the top of the page
void Header (){
	printf("\n\tDavid Pearson 1725412\n\t5CS021\n\tNumerical Methods in C\n\t1.3 Cubic Polynomials\n\n");
}

//Function reads in the two sets of co-ordinates
void ReadIn (){
	printf("\tEnter the value for A = ");
	scanf("%lf", &a);
	printf("\tEnter the value for  B = ");
	scanf("%lf", &b);
	printf("\tEnter the  value for C = ");
	scanf("%lf", &c);
	printf("\tEnter the  value for D = ");
	scanf("%lf", &d);
}

//Function to clear the screen
void Clear(){
    printf("\033[H\033[J");
}

//Better Function to find the first root
void FirstRoot(){
	while ((float)lastGuess != (float)G && (((a*(G*G*G))+(b*(G*G))+(c*G)+d) != 0))
	{
		lastGuess = G;
		G = cbrt(-((b*G*G + c*G + d) / a));
	}
	R1 = G;
}

//Function to solve remaining two roots, using quadratic formula
void Solve(){
	p=((d*-1)/R1);
	n=(b+(R1*a));
	R2 = ((n*-1) + sqrt((n*n)-(4*a*p)))/(2*a);
	R3 = ((n*-1) - sqrt((n*n)-(4*a*p)))/(2*a);
}

//function to print the roots
void PrintRoots(){
		printf("\n\tRoot 1 = %.2lf\n\tRoot 2 = %.2lf\n\tRoot 3 = %.2lf\n",R1,R2,R3);
}
