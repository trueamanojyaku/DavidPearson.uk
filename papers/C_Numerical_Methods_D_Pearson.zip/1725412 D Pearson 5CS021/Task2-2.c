// Libraries that need to be loaded
#include <stdio.h> 
#include <stdlib.h>
#include <pthread.h>
#include <string.h>

//function declarations
void header ();
void clear ();
int fileLength(char *filename);
void addwords(char* filename, int start, int end);

struct word {
	char word[255];
	int count;
};

struct word *wordStructList;

int main(int argc, char *argv[] ){
	clear();
	header();
	if (argc != 5){
		printf("\tYou have not entered enough arguments\n\tThis requires you to enter 4 file names");
	}
	int A = fileLength(argv[1]);
	printf("\n\t%s contains %d words\n",argv[1], A);
	int B = fileLength(argv[2]);
	printf("\n\t%s contains %d words\n",argv[2], B);
	int C = fileLength(argv[3]);
	printf("\n\t%s contains %d words\n",argv[3], C);
	int D = fileLength(argv[4]);
	printf("\n\t%s contains %d words\n",argv[4], D);

 	long totalWords = A+B+C+D;
	printf("\n\tThe total number of words read in is %ld\n", totalWords);
	
	wordStructList = malloc(sizeof(struct word)*totalWords);
	
	addwords(argv[1],0,A);
	addwords(argv[2],A,(A+B));
	addwords(argv[3],(A+B),(A+B+C));
	addwords(argv[4],(A+B+C),(A+B+C+D));
	
	/*method to count the words, logic is:
	* (1) for each word, first look at the count if its the
	* 	  first time you have seen the word i.e. the count is 0
	*     set the count to 1
	* (2) if the count is -1 then the word has been counted
	*     move onto the next word
	* (3) if the count is greater than 0 this means this is the
	*     word we are incrementing count on
	* (4) now compare this word to every other word in the list
	* (5) If the word you are comparing it to has count of -1
	*     move onto the next word to compare to
	* (6) if the comparing word count is 0 then we want to 
	*     compare them
	* (7) Compare the first word with a count of 1 to all 
	*      words with a count of 0
	* (8) if they are the same then increment the count by 1 
	*     and set the compared words count to -1
	*/
	for(int i = 0; i < totalWords; i++){
		if(wordStructList[i].count == -1){		
		}
		if(wordStructList[i].count == 0){		
			wordStructList[i].count = 1;
		}
		if(wordStructList[i].count > 0){
			for(int x = 1; x < totalWords; x++){
				if(wordStructList[x].count == -1){
				}
				if(wordStructList[x].count == 0){
					int check = strcmp(wordStructList[i].word,wordStructList[x].word);
						if (check==0){
							++wordStructList[i].count;		
							wordStructList[x].count = -1;
						}
				}
			}		
		}
	}
	
	int uwords = 0;
	FILE *outFile;
	outFile = fopen("Task2-2Output.txt", "w");
	for (int c = 0; c < totalWords; c++) {
		if (wordStructList[c].count > 0){
			fprintf(outFile,"%s x %d\n",wordStructList[c].word,wordStructList[c].count);
			uwords++;
		}		
	}
	fclose(outFile);

	printf("\n\tThe number of unique words are %d\n", uwords);
	printf("\n\tResults have been saved in Task2-2Output.txt\n");
}


//Function returns header at the top of the page
void header () {
	printf("\n\tDavid Pearson 1725412");
	printf("\n\t5CS021\n\tNumerical Methods in C");
	printf("\n\t2.2 Word Count\n");
}

//Function to clear the screen
void clear() {
    printf("\033[H\033[J");
}

/*
Function to get the length of the file, by counting
the new line characters
*/
int fileLength(char *filename){
	int length = 0;
	FILE *myFile;
	myFile = fopen(filename, "r");
	while(!feof(myFile)) {	
  		int ch = fgetc(myFile);
  			if(ch == '\n'){
    			length++;
  			}
	}
	fclose(myFile);
	return length;
}


//Function to add words from the file to the struct word list
void addwords(char* filename, int start, int end){
	FILE *myFile;
   	myFile = fopen(filename,"r");
   	for(int i = start; i < end; i++){
		fscanf(myFile, "%s", wordStructList[i].word);
		wordStructList[i].count = 0;
   	}
   	fclose(myFile);
}



