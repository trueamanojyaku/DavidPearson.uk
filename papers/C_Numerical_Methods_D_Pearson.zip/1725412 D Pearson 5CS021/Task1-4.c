#include <stdio.h> 
#include <stdlib.h>

//function declarations
void Header ();
int fileSize();
void LinearFunction();
void Clear ();

//Instance Variables
int size = 0;
int ch = 0;
double a,b ;
double xsum = 0;
double ysum = 0;
double xsqsum = 0;
double xysum = 0;
int c1,c2,c3;

//Main Program
int main(int argc, char *argv[] ){
Clear();
Header();
fileSize(argv[1]);
LinearFunction(argv[1]);
}

//Function returns header at the top of the page
void Header (){
	printf("\n\tDavid Pearson 1725412\n\t5CS021\n\tNumerical Methods in C\n\t1.4 Linear Regression\n\n");
}

//Function to get the size of the file
int fileSize(char *filename){
	FILE *myFile;
	myFile = fopen(filename, "r");
	while(!feof(myFile)){	
  		ch = fgetc(myFile);
  			if(ch == '\n') {
    			size++;
  			}
	}
	rewind(myFile);
	return size;
}

//Function to create and populate the arrays and Solve
void LinearFunction(char *filename){
	FILE *myFile;
	myFile = fopen(filename, "r");
	int xArray[size+1];
	int yArray[size+1];
		for (c1 = 0; c1 <size; c1++) {
			fscanf(myFile, "%d,%d\n", &xArray[c1], &yArray[c1]);
		}
	fclose(myFile);
	for (c2 = 0; c2 <size; c2++) {
		xsum = xsum + xArray[c2];
		ysum = ysum + yArray[c2];
		xsqsum = xsqsum + (xArray[c2] * xArray[c2]);
		xysum = xysum + (xArray[c2] * yArray[c2]);
	}
	int n = size;
	a = ((ysum*xsqsum)-(xsum*xysum)) / ((n*xsqsum)-(xsum*xsum));
	b = ((n*xysum)-(xsum*ysum)) / ((n*xsqsum)-(xsum*xsum));
	double m,c;
	m = b;
	c = a;	
	printf("\ty = mx + c\n\ty = %.2lfx + %.2lf\n",m,c); 
	double newX,newY;
	printf("\tPlease enter a value for X = ");
	scanf("%lf", &newX);
	newY = (m*newX)+c;
	printf("\ty = %.2f\n",newY);
}

//Function to clear the screen
void Clear(){
    printf("\033[H\033[J");
}
