package itemSrc;

import java.util.LinkedList;
/**
 * This class maintains a linked list of customers, as if it were a queue
 *
 * @author David Pearson 1725412
 */
public class CustomerQueue extends LinkedList
{
    /**
     * Defines the LinkedList that holds Customer Objects and names it 'queue'
     */
    private LinkedList <Customer> queue;

	/**
	 * Constructor for a Customer Queue
	 * when called a LinkedList called 'queue' is created to hold
	 * objects of type customer
	 */
    public CustomerQueue() {
    	queue = new LinkedList <Customer>();
    }

    /**
     * This method adds an object of type Customer to the LinkedList
     *
     * @param details is the name of the Customer Object to be added
     */
    public  void addCustomer(Customer details) {
    	queue.add(details); // do i want to use the CustomerNumber as an index?
    }

    /**
     * This method returns the number of elements in the LinkedList
     *
     * @return the number of Customer Objects in the queue
     */
    public int getQueueSize()
    {
    	return queue.size();
    }

    /**
     * This method iterates through the LinkedList and checks
     * each Customer Object for the value of 'Queueing', if the
     * value is true then the count increases, if false it does not
     *
     * @return the number of customers who are set to queueing
     */
    public  int getNumberQueueing () {
    	int count = 0;
    		 for (Customer cq : queue) {
    			if (cq.isQueueing()) {
    				count++;
    			}
    		 }
    	return count;
    }

    /**
     * This method searches the LinkedList using the 'i' passed in
     * and returns the customer object in that position.
     *
     * @param i is the customer object position wanted
     *
     * @return the customer object at position 'i' within the LinkedList
     */
    public Customer get(int i) {
    	return queue.get(i);
    }

    /**
     * This method Retrieves and removes the first Customer Object in the queue
     * if there are no Customers then NULL is returned
     *
     * @return the customer object stored as the first element
     */
    public  Customer getNext() {
    	Customer cq = null;
    	cq = queue.pollFirst();
        return cq;
    }

    /**
     * This method creates a StringBuilder, then calls the ToString Method
     * for each Customer Object in the LinkedList and appends them to the
     * StringBuffer separated by a newline
     *
     * @return a string of all customer details in the linkedList,
     * one customer per line
     */
    public String getQueueString() {
    	StringBuilder sb = new StringBuilder();
		for (Customer cq : queue) {
			if (cq.isQueueing()) {
				sb.append(cq.toString() + "\n");
			}
		}
		return sb.toString();
    }

    /**
     * This method uses a for each loop and iterates though the queue
     * calling the isQueueing method of the customer object and setting
     * it to 'true' for each customer object in the LinkedList
     */
    public  void  setAllQueueing() {
    	for (Customer cq : queue) {
			if (!cq.isQueueing()) {
				cq.setQueueing(true);
			}
		}
    }

}
