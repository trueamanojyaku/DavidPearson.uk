﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class Manager : MonoBehaviour
{
    //************************************* Variables *************************************

    private AStarManager AStarManager = new AStarManager();         // The A* manager.
    List<GameObject> Waypoints = new List<GameObject>();            // Array of nodes.
    List<Connection> ConnectionArray = new List<Connection>();      // Array of  connections 
    List<GameObject> Goals = new List<GameObject>();                // Array of Goal objects

    public GameObject Home;                                         // Base location
    public GameObject Goal1;                                        // Goal location
    public GameObject Goal2;                                        // Goal location
    public GameObject Goal3;                                        // Goal location
    public GameObject Goal4;                                        // Goal location
    public GameObject Goal5;                                        // Goal location
    public GameObject Goal6;                                        // Goal location
    public GameObject Goal7;                                        // Goal location
    public GameObject Goal8;                                        // Goal location
    public GameObject END;                                          // End location
    public int PaintTins = 10;                                      // Number of items being carried
    private float TotalDistanceTravelled = 0;                       // Variable to store distance travelled
    private Vector3 previousPosition;                               // Variable used in distance calculation
    private float startTime;                                        // Variable to help count time taken
    Vector3 OffSet = new Vector3(0, 0.3f, 0);                       // Debug line offset
    public Transform self;                                          // Public Self object
    private int count = 0;                                          // Variable used to travel along the connections
    private int GCount = 0;                                         // Variable used to count goals visited
    private float MinSpeed = 20;                                    // Minimum Speed Variable
    public float Speed = 200;                                       // Speed Variable
    private float MaxSpeed = 400;                                   // Maximum Speed variable
    private float TempSpeed = 0;                                    // Temporary Speed variable
    enum GameStates { Normal, Wait, Backoff };                      // Enums for the three states
    GameStates State = GameStates.Normal;                           // Sets default state as normal
    enum GameEvents { ON_ENTER, ON_UPDATE };                        // Declares two GameEvents on_enter and on_update
    GameEvents Event = GameEvents.ON_ENTER;                         // Sets the default event to be on enter
    private float t = 0;                                            // Variable for storing time
    private string minutes, seconds;                                // Variables to display minutes and seconds
    public float priority = 0;                                      // Variable used to calculate priority
    public float scale = 1f;                                        // Variable used to shrink the object
    public float otherPriority = 0;                                 // Variable to store another agents priority
    public bool CanMove = true;                                     // Variable used to control movement


    //************************************* START *************************************
    void Start()
    {

        Speed = (MaxSpeed - (PaintTins * (MaxSpeed / 10)));           // Reduce speed by 10% per item carried
        if (Speed < 1) { Speed = (MaxSpeed / 10); }                  // If speed is reduced by more than 90% of max set speed to 10%
        previousPosition = self.position;                           // Set previousPosition variable to current position
        startTime = Time.time;                                      // Set start time variable to the system time
        Goals.Add(Goal1);                                           // Add the goal into the goals array
        Goals.Add(Goal2);                                           // Add the goal into the goals array
        Goals.Add(Goal3);                                           // Add the goal into the goals array
        Goals.Add(Goal4);                                           // Add the goal into the goals array
        Goals.Add(Goal5);                                           // Add the goal into the goals array
        Goals.Add(Goal6);                                           // Add the goal into the goals array
        Goals.Add(Goal7);                                           // Add the goal into the goals array
        Goals.Add(Goal8);                                           // Add the goal into the goals array
        Goals.Add(END);                                             // Add the End into the goals array

        //populate an array of waypoints and waypoint connections
        GameObject[] GameObjectsWithWaypointTag;
        GameObjectsWithWaypointTag = GameObject.FindGameObjectsWithTag("Waypoint");
        foreach (GameObject waypoint in GameObjectsWithWaypointTag)
        {
            WaypointCON tmpWaypointCon = waypoint.GetComponent<WaypointCON>();
            if (tmpWaypointCon)
            {
                Waypoints.Add(waypoint);
            }
        }
        // Go through the waypoints and create connections.
        foreach (GameObject waypoint in Waypoints)
        {
            WaypointCON tmpWaypointCon = waypoint.GetComponent<WaypointCON>();
            // Loop through a waypoints connections.
            foreach (GameObject WaypointConNode in tmpWaypointCon.Connections)
            {
                Connection aConnection = new Connection();
                aConnection.SetFromNode(waypoint);
                aConnection.SetToNode(WaypointConNode);
                AStarManager.AddConnection(aConnection);
            }
        }
        // Call the A Star method and pass in the start and end locations
        ConnectionArray = AStarManager.PathfindAStar(Home, Goals[GCount]);
    }



    //************************************* UPDATE *************************************
    void Update()
    {
        FSMUpdate();                                            // Update the agent state
        t = Time.time - startTime;                              // Create a variable called T and store the current time minus the start time in it
        minutes = ((int)t / 60).ToString();                     // Convert T into a string to represent minutes
        seconds = ((int)t % 60).ToString("f0");                 // Convert T into a string to represent seconds, to no decimal places             
        TotalDistanceTravelled += Vector3.Distance(self.position, previousPosition);    // Increment the total distance traveled since last update
        previousPosition = self.position;                       // Update the previous position variable


        /*
         * This is used to calculate how much priority one agent has over another
         * 
         * Faster current speed scores higher than slower 0<->400
         * more drops remaining scores higher than fewer, each drop remaining is worth 50
         * The further the distance travelled scores higher
         * Percentage of node to node journey completed scores higher
         * Plus distance as the crow flies from base
         * 
         */
        float distToHome = Vector3.Distance(self.transform.position, Home.transform.position);
        if (distToHome > 5)
        {
            priority = Speed + ((Goals.Count - GCount) * 50) + TotalDistanceTravelled + ((ConnectionArray.Count / (ConnectionArray.Count - count)) * 75) + distToHome;
        }
    }
    /*
    * OnDrawGizmos method
    * 
    * For each connection in the array of connections create a gizmo and set the colour to green
    * then call the drawline method with start node and end node as arguments.
    */
    void OnDrawGizmos()
    {
        foreach (Connection aConnection in ConnectionArray)
        {
            Gizmos.color = Color.green;
            Gizmos.DrawLine((aConnection.GetFromNode().transform.position + OffSet),
           (aConnection.GetToNode().transform.position + OffSet));
        }
    }

    /*
     * Finite State Machine Update method
     * 
     * 
     */

    private void FSMUpdate()
    {
        // --- NORMAL ---
        if (State == GameStates.Normal)
        {
            if (Event == GameEvents.ON_ENTER)
            {
                normal_Enter();
            }
            if (Event == GameEvents.ON_UPDATE)
            {
                normal_Update();
            }
        }
        // --- WAIT ---
        if (State == GameStates.Wait)
        {
            if (Event == GameEvents.ON_ENTER)
            {
                wait_Enter();
            }
            if (Event == GameEvents.ON_UPDATE)
            {
                wait_Update();
            }
        }
        // --- Backoff ---
        if (State == GameStates.Backoff)
        {
            if (Event == GameEvents.ON_ENTER)
            {
                backOff_Enter();
            }
            if (Event == GameEvents.ON_UPDATE)
            {
                backOff_Update();
            }
        }
    }

    /*
     * Change Finite State Machine function
     */
    private void ChangeFSMState(GameStates newState)
    {
        switch (State)
        {
            case GameStates.Normal:
                normal_Exit();
                break;
            case GameStates.Wait:
                wait_Exit();
                break;
            case GameStates.Backoff:
                backOff_Exit();
                break;
        }
        State = newState;
        Event = GameEvents.ON_ENTER;
    }

    //************************************* NORMAL STATE *************************************
    // Idle - enter.
    private void normal_Enter()
    {
        // Change to update at the end of enter.
        Event = GameEvents.ON_UPDATE;
    }
    // Idle - update.
    private void normal_Update()
    {
        /*
         * Main Movement method logic
         * 
         * (0)    Check the correct speed for the agent is set
         * 
         * (1)    Check to see if the GCount variable is less than the number of elements in the Goals Array
         *  
         * (2)    Create and populate three variables that hold the distance between the agent and specific elements
         *       2.1)    Agent Location <---> Current Goal location
         *       2.2)    Agent Location <---> Final End Location
         *       2.3)    Agent Location <---> Next Node in path Location
         *       
         * (3)    Depending on the proximity to each of these three elements If statements dictate the next step
         *  
         * (4)    If 2.3 is less than 3 then increment the count variable
         *  
         * (5)    If 2.2 is less than 5 then increment the GCount variable and print final data to the console
         *  
         * (6)    If 2.1 is less than 5 and Gcount is less than the number of elements in the goals array
         *       6.1)   Call the AStar method passing in the current Goal and next Goal as arguments
         *       6.2)   Increment the GCount variable
         *       6.3)   Decrease the PaintTins variable by 1
         *       6.4)   Reset Speed to its maximum
         *       6.5)   Reduce speed by 10% x number of paint tins left
         *       6.6)   Set Colour reduction variable inline with how many deliveries made#
         *       6.7)   Update the Colour of the agent
         *       6.8)   Update the console with pertinent statistical information
         *       6.9)   Reset the count variable
         *       
         * (7)    Move the Agent from where it is towards the current connections "toNode"   
         * 
         */
        Speed = MaxSpeed;
        Speed = (Speed - (PaintTins * (MaxSpeed / 10)));
        if (Speed < 1)
        {
            Speed = MinSpeed + 20;
        }
        if (GCount < Goals.Count)
        {
            float distanceToGoal = Vector3.Distance(self.transform.position, Goals[GCount].transform.position);
            float distanceToEND = Vector3.Distance(self.transform.position, Goals[Goals.Count - 1].transform.position);
            float distanceToNextNode = Vector3.Distance(self.transform.position, ConnectionArray[count].GetToNode().transform.position);
            if (distanceToNextNode < 3) { count++; }
            if (distanceToEND < 5)
            {
                GCount++;
                Debug.Log(self.name + " has finished with a toal time of " + minutes + ":" + seconds + " & a total distance travelled of " + TotalDistanceTravelled.ToString("f2"));
            }
            if (distanceToGoal < 5 && GCount < Goals.Count - 1)
            {
                ConnectionArray = AStarManager.PathfindAStar(Goals[GCount], Goals[GCount + 1]);
                GCount++;
                PaintTins--;
                Speed = MaxSpeed;
                Speed = (Speed - (PaintTins * (MaxSpeed / 10)));
                self.transform.localScale -= new Vector3(scale, scale, scale);
                Debug.Log(self.name + " has reached goal number " + GCount + " in a total time of " + minutes + ":" + seconds + " Speed now increased by 10%");
                count = 0;
            }
            self.position = Vector3.MoveTowards(self.position, ConnectionArray[count].GetToNode().transform.position, Speed * Time.deltaTime);
        }

    }
    // Idle - Exit.
    private void normal_Exit()
    {
    }
    //************************************* WAIT STATE *************************************
    // Move - Enter.
    private void wait_Enter()
    {
        // Declare who has priority
        // Change to update at the end of enter.
        Debug.Log(self.name + priority + " vs " + otherPriority);
        if (otherPriority > priority)
        {
            Debug.Log(self.name + " I have a lower priority and am going to stop" + priority);
            CanMove = false;
            Speed = 0;
        }
        else
        {
            Debug.Log(self.name + " I have a higher proirity and will continue at a slower speed" + priority);
            Speed = MinSpeed;
            CanMove = true;
        }

        Event = GameEvents.ON_UPDATE;
    }
    // Move - Update.
    private void wait_Update()
    {
        if (CanMove == true)
        {
            self.position = Vector3.MoveTowards(self.position, ConnectionArray[count].GetToNode().transform.position, Speed * Time.deltaTime);
            float distanceToNextNode = Vector3.Distance(self.transform.position, ConnectionArray[count].GetToNode().transform.position);
            if (distanceToNextNode < 3) { count++; }
        }
        // Could cause a state change. Must call state change method.
    }
    // Move - Exit.
    private void wait_Exit()
    {
    }
    //************************************* BACKOFF STATE *************************************
    // Retreat - Enter.
    private void backOff_Enter()
    {
        // Change to update at the end of enter.
        Event = GameEvents.ON_UPDATE;
    }
    // Retreat - Update.
    private void backOff_Update()
    {
        // Implement game state here.
        // Could cause a state change. Must call state change method.
    }
    // Retreat - Exit.
    private void backOff_Exit()
    {
    }


    //************************************* DEALING WITH OTHER AGENTS *************************************

    void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Agent")
        {
            TempSpeed = Speed;
            Debug.Log(self.name + " is near " + other.gameObject.name);
            otherPriority = other.gameObject.GetComponent<Manager>().priority;
            ChangeFSMState(GameStates.Wait);
        }
    }
    void OnTriggerExit(Collider other)
    {
        if (other.tag == "Agent")
        {
            Debug.Log(self.name + " no one is near me returning to normal");
            Speed = TempSpeed;
            CanMove = true;
            ChangeFSMState(GameStates.Normal);
        }
    }
}