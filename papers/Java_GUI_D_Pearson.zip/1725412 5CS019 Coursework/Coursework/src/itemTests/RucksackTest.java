package itemTests;

import static org.junit.Assert.*;

import org.junit.Test;

import itemSrc.*;

/**
 * JUnit test class for the Rucksack class
 * @author David Pearson
 *
 */
public class RucksackTest {

	Rucksack  r;
	/**
	 * This tests the constructor for a Rucksack object
	 */
	@Test
	public void testParcel() {
		  r = new Rucksack("bk021", 2, 3, 4, 3, 9);
		  assertEquals(r.getId(), "bk021");
	}

	/**
	 * This tests the getId method for a rucksack object
	 */
	@Test
	public void testGetId() {
		  r = new Rucksack("bk0221", 2, 3, 4, 8, 9);
		  assertEquals(r.getId(),"bk0221");
	}

	/**
	 * This tests the SetID method for a rucksack object
	 */
	@Test
	public void testSetId() {
		 r = new Rucksack("bk0221", 2, 3, 4, 8, 9);
		 assertSame(r.getId(),"bk0221");
		 r.setId("pe3p");
		 assertEquals(r.getId(),"pe3p");
	}

	/**
	 * This tests the GetDays method for a rucksack object
	 */
	@Test
	public void testGetDays() {
		 r = new Rucksack("bk0221", 2, 3, 4, 8, 9);
		 assertSame(r.getDays(),2);
	}

	/**
	 * This tests the setCapacity method for a rucksack object
	 */
	@Test
	public void testSetCapacity() {
		 r = new Rucksack("bk0221", 2, 3, 4, 8, 9);
		 assertSame(r.getDays(),2);
		 r.setDays(1);
		 assertSame(r.getDays(),1);
	}

	/**
	 * This tests the getLength method for a rucksack object
	 */
	@Test
	public void testGetLength() {
		 r = new Rucksack("bk0221", 2, 3, 4, 8, 9);
		 assertSame(r.getLength(),3);
	}

	/**
	 * This tests the setLength method for a rucksack object
	 */
	@Test
	public void testSetLength() {
		 r = new Rucksack("bk0221", 2, 3, 4, 8, 9);
		 assertSame(r.getLength(),3);
		 r.setLength(5);
		 assertSame(r.getLength(),5);
	}

	/**
	 * This tests the getWidth method for a rucksack object
	 */
	@Test
	public void testGetWidth() {
		 r = new Rucksack("bk0221", 2, 3, 4, 8, 9);
		 assertSame(r.getWidth(),4);
	}

	/**
	 * This tests the setWidth method for a rucksack object
	 */
	@Test
	public void testSetWidth() {
		 r = new Rucksack("bk0221", 2, 3, 4, 8, 9);
		 assertSame(r.getWidth(),4);
		 r.setWidth(7);
		 assertSame(r.getWidth(),7);
	}

	/**
	 * This tests the getHeight method for a rucksack object
	 */
	@Test
	public void testGetHeight() {
		 r = new Rucksack("bk0221", 2, 3, 4, 8, 9);
		 assertSame(r.getHeight(),8);
	}

	/**
	 * This tests the setHidth method for a rucksack object
	 */
	@Test
	public void testSetHeight() {
		 r = new Rucksack("bk0221", 2, 3, 4, 8, 9);
		 assertSame(r.getHeight(),8);
		 r.setHeight(2);
		 assertSame(r.getHeight(),2);
	}

	/**
	 * This tests the getHidth method for a rucksack object
	 */
	@Test
	public void testGetWeight() {
		 r = new Rucksack("bk0221", 2, 3, 4, 8, 9);
		 assertSame(r.getWeight(),9);
	}

	/**
	 * This tests the setHidth method for a rucksack object
	 */
	@Test
	public void testSetWeight() {
		 r = new Rucksack("bk0221", 2, 3, 4, 8, 9);
		 assertSame(r.getWeight(),9);
		 r.setWeight(11);
		 assertSame(r.getWeight(),11);
	}

	/**
	 * This tests the isCollected method for a rucksack object
	 */
	@Test
	public void testIsCollected() {
		 r = new Rucksack("bk0221", 2, 3, 4, 8, 9);
		 assertSame(r.isCollected(),false);
	}

	/**
	 * This tests the setCollected method for a rucksack object
	 */
	@Test
	public void testSetCollected() {
		 r = new Rucksack("bk0221", 2, 3, 4, 8, 9);
		 assertFalse(r.isCollected()!=false);
		 r.setCollected();
		 assertTrue(r.isCollected()==true);
	}


	/**
	 * This tests the testEquals method for a rucksack object
	 * by comparing two rucksack objects
	 */
	@Test
	public void testEquals() {
		r = new Rucksack ("bk0221", 2, 3, 4, 8, 9);
		Rucksack r2 = new Rucksack ("ab0111", 5, 5, 5, 5, 5);
		Customer c1 = new Customer("Adam", "AA00");
		assertFalse(r.equals(r2));
		assertFalse(r2.equals(c1));
	}

	/**
	 * This tests the testCompareTo method for a rucksack object
	 * returning a greater than 0, equal to 0, or less than 0
	 */
	@Test
	public void testCompareTo() {
		r = new Rucksack ("bk0221", 2, 3, 4, 8, 9);
		Rucksack r2 = new Rucksack ("ab0111", 5, 5, 5, 5, 5);
		Rucksack r3 = new Rucksack ("ZZ0169", 5, 5, 5, 5, 5);
		Rucksack r4 = new Rucksack ("ZY0666", 5, 5, 5, 5, 5);
		assertTrue(r3.compareTo(r4)>0);
		assertSame(r3.compareTo(r3),0);
		assertTrue(r3.compareTo(r2)<0);
	}

	/**
	 * This test overrides the ToString method
	 */
	@Test
	public void testToString() {
		r = new Rucksack ("bk0221", 2, 3, 4, 8, 9);
		assertEquals(r.toString(),"Rucksack [id=bk0221, days=2, length=3, width=4, height=8, weight=9, collected:false]");
	}

}
