package itemTests;

import static org.junit.Assert.*;

import org.junit.Test;

import itemSrc.*;

/**
 * JUnit test class for the Manager class
 * @author David Pearson 1725412
 */
public class ManagerTest {
	
/**
 * This tests the Manager Constructors various elements
 * the logic is as follows
 * (1) create a manger object called m1
 * (2) Call the initaliseData method
 * (3) Check that all customers have been added to the custQ that belongs to the manager
 * (4) check that all the rucksacks have been added to the rucksack map
 * (5) create a worker
 * (6) add the worker to the manager object
 * (7) check that the name of the worker is correct via the manager object
 */
	@Test
	public void testManager() {
		Manager m1 = new Manager();
		m1.initialiseData("Custs.csv","Orders.csv");
		assertEquals(m1.custQ.getQueueSize(),30,0);
		assertEquals(m1.allRucksacks.getNumberOfEntries(),30,0);
		Worker w1 = new Worker (m1.custQ,m1.allRucksacks,"Pedro");
		m1.workers[0] = w1;
		assertSame(m1.workers[0].getName(),"Pedro");
	}

	/**
	 * This tests the initialise Data method
	 * 
	 */
	@Test
	public void testInitialiseData() {
		Manager m1 = new Manager();
		m1.initialiseData("Custs.csv","Orders.csv");
		assertEquals(m1.custQ.getQueueSize(),30,0);
		assertEquals(m1.allRucksacks.getNumberOfEntries(),30,0);
	}

	/**
	 * This tests the readCustFile Method
	 */
	@Test
	public void testReadOrderFile() {
		Manager m1 = new Manager();
		m1.readCustFile("Custs.csv");
		assertEquals(m1.custQ.getQueueSize(),30,0);
	}
	
	/**
	 * This tests the readCustFile Method
	 */
	@Test
	public void testReadOrdersFile() {
		Manager m1 = new Manager();
		m1.readOrderFile("Orders.csv");
		assertEquals(m1.allRucksacks.getNumberOfEntries(),30,0);
	}

}
