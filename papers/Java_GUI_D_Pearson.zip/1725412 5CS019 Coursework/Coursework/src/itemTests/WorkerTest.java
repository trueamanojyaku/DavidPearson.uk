package itemTests;

import static org.junit.Assert.*;

import org.junit.*;

import itemSrc.*;
/**
 * JUnit test class for the Worker class
 * @author David Pearson 1725412
 */

public class WorkerTest {

	Worker worker1;
/**
 * This tests the Worker constructor
 * Logic is as follows
 * (1) Create a queue
 * (2) Create two test Customers
 * (3) Add Customers to the queue
 * (4) Set the customers to queueing
 * (5) check Queue size is equal to 2
 * (6) Create a RucksackMap
 * (7) Create two Rucksacks
 * (8) Add the rucksacks to the Map
 * (9) check that the Map has 2 entries
 * (10)Create a worker
 * (11)Check the name of the worker
 * (12)Call GetNext Method and Check that the name of the customer Matches
 * (13)Repeat for second customer
 */
	@Test
	public void testWorker() {
		CustomerQueue queue = new CustomerQueue();
		assertEquals(queue.getQueueSize(),0,0);
		Customer c1 = new Customer("Adam", "AA11");
		Customer c2 = new Customer("Eve", "BB22");
		queue.addCustomer(c1);
		queue.addCustomer(c2);
		queue.setAllQueueing();
		assertEquals(queue.getQueueSize(),2,0);
		
		RucksackMap rucksackList = new RucksackMap();
		Rucksack r1 = new Rucksack("AA11", 2, 5, 4, 3,1);
		Rucksack r2 = new Rucksack("BB22", 1, 3, 2, 3,1);
		rucksackList.addDetails(r1);
		rucksackList.addDetails(r2);
		assertEquals(rucksackList.getNumberOfEntries(),2,0);
		
		worker1 = new Worker (queue,rucksackList,"Pedro");
		assertSame(worker1.getName(),"Pedro");
		assertEquals(worker1.getNext().getName(),"Adam");
		assertEquals(worker1.getNext().getName(),"Eve");
	}
	
/**
 * This tests the getCurrentCust method
 * 
 */
	@Test
	public void testGetCurrentCust() {
		CustomerQueue queue = new CustomerQueue();
		assertEquals(queue.getQueueSize(),0,0);
		Customer c1 = new Customer("Andrew", "px21");
		Customer c2 = new Customer("Janice", "lt64s");
		
		queue.addCustomer(c1);
		queue.addCustomer(c2);
		queue.setAllQueueing();
		
		RucksackMap parcelList = new RucksackMap();
		Rucksack p = new Rucksack("lt64s", 2, 5, 4, 3,1);
		
		Rucksack p2 = new Rucksack("ntqx", 1, 3, 2, 3,1);
		parcelList.addDetails(p);
		parcelList.addDetails(p2);
		
		worker1 = new Worker( queue, parcelList, "Adam");
		assertEquals(queue.getNext(),c1);
		assertEquals(queue.getNext(),c2);
		assertSame(worker1.getCurrentCust(),null);
	}

/**
 * This has already been tested with the constructor
 */
	@Test
	public void testGetName() {
		CustomerQueue queue = new CustomerQueue();		
		RucksackMap rucksackList = new RucksackMap();		
		worker1 = new Worker (queue,rucksackList,"Pedro");
		assertSame(worker1.getName(),"Pedro");		
	}
	
/**
 * This tests the get state and change state method for the worker.
 */
	@Test
	public void testGetState() {
		CustomerQueue queue = new CustomerQueue();		
		RucksackMap rucksackList = new RucksackMap();		
		worker1 = new Worker (queue,rucksackList,"Pedro");
		assertTrue(worker1.getState());
		worker1.changeState();
		assertFalse(worker1.getState());	
	}

/**
 * This tests the ProcessOneCustomer method
 * 
 */
	@Test
	public void testProcessOneCustomer() {
		CustomerQueue queue = new CustomerQueue();
		assertEquals(queue.getQueueSize(),0,0);
		Customer c1 = new Customer("Adam", "AA11");
		Customer c2 = new Customer("Eve", "BB22");
		
		queue.addCustomer(c1);
		queue.addCustomer(c2);
		queue.setAllQueueing();
		
		RucksackMap parcelList = new RucksackMap();
		Rucksack p = new Rucksack("AA11", 2, 5, 4, 3,1);
		Rucksack p2 = new Rucksack("BB22", 1, 3, 2, 3,1);
		parcelList.addDetails(p);
		parcelList.addDetails(p2);
		
		assertEquals(queue.getQueueSize(),2,0);
		
		worker1 = new Worker( queue, parcelList, "Adam");
		assertFalse(worker1.getFinished());
		worker1.processOneCustomer();
		assertEquals(queue.getQueueSize(),1,0);
		worker1.processOneCustomer();
		assertEquals(queue.getQueueSize(),0,0);
		assertTrue(worker1.getFinished());
		worker1.processOneCustomer();
	}

}
