package itemSrc;


/**
 * This is the Rucksack object class
 * it holds information and methods for the RuckSack Item
 *
 * @author David Pearson
 *
 */

public class Rucksack implements Comparable <Rucksack>
{
	/**
	 * id - to identify each Rucksack(item)
	 * days - number of days waiting to be collected
	 * width, height, weight - dimensions and how heavy
	 * collected - shows if the rucksack has been collected
	 */
	// Rucksack attributes
	private String id;
	private int days;
	private int length;
	private int width;
	private int height;
	private int weight;
	private boolean collected = false;

 /**
  * Constructor for a Rucksack object
  *
  * @param id the unique Rucksack ID
  * @param days
  * @param length in cm of the Rucksack
  * @param width in cm of the Rucksack
  * @param height in cm of the Rucksack
  * @param weight in KG of the Rucksack
  */
    public Rucksack(String id, int days, int length, int width, int height,	int weight) {
		this.id = id;
		this.days = days;
		this.length = length;
		this.width = width;
		this.height = height;
		this.weight = weight;
	}


    /**
     * Gets the ID of the Rucksack
     *
     * @return The Rucksack object ID
     */
	public String getId(){
		return id;
	}

	/**
	 * Gets the number of days
	 *
	 * @return the number of days
	 */
	public int getDays() 	{
		return days;	}

	/**
	 * Gets the length of the Rucksack
	 *
	 * @return the length in cm
	 */
	public int getLength()	{
		return length;
	}

	/**
	 * Gets the width of the Rucksack
	 *
	 * @return the width in cm
	 */
	public int getWidth()	{
		return width;
	}

	/**
	 * Gets the height of the Rucksack
	 *
	 * @return the height in cm
	 */
	public int getHeight()	{
		return height;
	}

	/**
	 * Gets the weight of the Rucksack
	 *
	 * @return the weight in kg
	 */
	public int getWeight()	{
		return weight;
	}


	/**
	 * Sets the ID of the rucksack object
	 *
	 * @param id for the rucksack object
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * Sets the number of days
	 *
	 * @param days
	 */
	public void setDays(int days) {
		this.days = days;
	}

	/**
	 * Sets the length of the rucksack object
	 *
	 * @param length in cm
	 */
	public void setLength(int length) {
		this.length = length;
	}

	/**
	 * Sets the width of the rucksack object
	 *
	 * @param width in cm
	 */
	public void setWidth(int width) {
		this.width = width;
	}

	/**
	 * Sets the heigth of the rucksack object
	 *
	 * @param height in cm
	 */
	public void setHeight(int height) {
		this.height = height;
	}

	/**
	 * Sets the weight of the rucksack object
	 *
	 * @param weight in cm
	 */
	public void setWeight(int weight) {
		this.weight = weight;
	}

	/**
	 * This method returns whether or not the rucksack has been
	 * collected
	 *
	 * @return True if it has been collected, false if it has not.
	 */
	public boolean isCollected() {
		return collected;
	}


	/**
	 * This method allows you to set the collected state of a
	 * rucksack object
	 *
	 * @param collected set to True if it has been collected, false if it has not
	 */
	public void setCollected() {
		this.collected = true;
	}


    /**
     * We want to compare this object against another, for the purpose
     * of sorting. The rucksacks are compared by id.
     * @param otherDetails - the rucksack to  be compared against.
     * @return a negative integer if this id comes before the parameter's id,
     *         zero if they are equal and a positive integer if this
     *         comes after the other.
     */

    public int compareTo(Rucksack otherDetails) {
    	return id.compareTo(otherDetails.getId());
    }

    /**
     * This method overrides the toString method and generates a string
     * containing the object data
     * Rucksack id days length width height weight collected
     * where id, days, length, width, height, weight, collected are values of those fields
     * @return a single string with all details of the rucksack
     */

	@Override
	public String toString() {
		return "Rucksack [id=" + id + ", days=" + days+ ", length=" + length
				+ ", width=" + width + ", height=" + height + ", weight="
				+ weight + ", collected:" + collected + "]";
	}

}
