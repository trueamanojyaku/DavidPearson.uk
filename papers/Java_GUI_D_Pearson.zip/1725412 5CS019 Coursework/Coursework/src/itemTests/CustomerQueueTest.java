package itemTests;

import static org.junit.Assert.*;

import org.junit.Test;

import itemSrc.*;

/**
 * JUnit test class for the CustomerQueue class
 * @author David Pearson 1725412
 */

public class CustomerQueueTest {
	
	CustomerQueue queue;

	/**
	 * This tests the constructor for the LinkedList
	 * it creates a new CustomerQueue called Queue, and
	 * then checks it is empty by calling the isEmpty method
	 */
	@Test
	public void testCustomerQueue() {
		CustomerQueue queue = new CustomerQueue();
		 assertTrue(queue.isEmpty());
	}
	
	/**
	 * This tests the AddCustomer method, first creating a queue,
	 * then creating a customer, adding the customer to the queue
	 * finally using the get method as a test.
	 */
	@Test
	public void testAddCustomer() {
		queue = new CustomerQueue(); 
		Customer c1 = new Customer("Adam", "AA00");
		queue.addCustomer(c1);
		assertSame(queue.get(0),c1);
	}
	
	/**
	 * This tests that the GetQueueSize is working correctly
	 * by adding a customer and testing the return value = 1
	 * then adding another customer and testing the return value = 2
	 */
	@Test
	public void testGetQueueSize() {
		queue = new CustomerQueue(); 
		Customer c1 = new Customer("Adam", "AA00");
		queue.addCustomer(c1);
		assertSame(queue.getQueueSize(),1);
		Customer c2 = new Customer("Eve", "BB11");
		queue.addCustomer(c2);
		assertSame(queue.getQueueSize(),2);
	}
	
	/**
	 * This Test checks that the getNumberQueueing is returing the 
	 * total number of customer objects in the queue that are also
	 * queueing
	 */
	@Test
	public void testGetNumberQueueing() {
		queue = new CustomerQueue(); 
		Customer c1 = new Customer("Adam", "AA00");
		queue.addCustomer(c1);
		queue.setAllQueueing();
		assertSame(queue.getNumberQueueing(),1);
		Customer c2 = new Customer("Eve", "BB11");
		queue.addCustomer(c2);
		queue.setAllQueueing();
		assertEquals(queue.getNumberQueueing(),2,0);
		
	}

	/**
	 * This tests the get method, ensuring that it returns the 
	 * customer object in the queue from the specified index 
	 * location
	 */
	@Test
	public void testGet() {
		queue = new CustomerQueue(); 
		Customer c1 = new Customer("Adam", "AA00");
		queue.addCustomer(c1);
		queue.setAllQueueing();
		assertSame(queue.get(0),c1);
		Customer c2 = new Customer("Eve", "BB11");
		queue.addCustomer(c2);
		queue.setAllQueueing();
		assertEquals(queue.get(1),c2);
		
	}

	/**
	 * This tests the GetNext method by adding two customers
	 * to the queue then calling GetNext twice
	 */
	@Test
	public void testGetNext() {
		queue = new CustomerQueue(); 
		Customer c1 = new Customer("Adam", "AA00");
		Customer c2 = new Customer("Eve", "BB11");
		queue.addCustomer(c1);		
		queue.addCustomer(c2);
		queue.setAllQueueing();
		assertSame(queue.getNext(),c1);
		assertSame(queue.getNext(),c2);
	}

	/**
	 * This tests the GetQueueString method is working
	 * 
	 */
	@Test
	public void testGetQueueString() {
		queue = new CustomerQueue(); 
		Customer c1 = new Customer("Adam", "AA00");
		Customer c2 = new Customer("Eve", "BB11");
		queue.addCustomer(c1);		
		queue.addCustomer(c2);
		queue.setAllQueueing();
		assertEquals(queue.getQueueString(),"Customer [name is :Adam, rID = AA00, qNum = 12, queueing : true]\n"
				+ "Customer [name is :Eve, rID = BB11, qNum = 13, queueing : true]\n");
	}

	/**
	 * This tests that the setAllQueueing method is working
	 * by calling GetNumberQueueing afterwards
	 */
	@Test
	public void testSetAllQueueing() {
		queue = new CustomerQueue(); 
		Customer c1 = new Customer("Adam", "AA00");
		Customer c2 = new Customer("Eve", "BB11");
		queue.addCustomer(c1);		
		queue.addCustomer(c2);
		queue.setAllQueueing();
		assertEquals(queue.getNumberQueueing(),2,0);
	}
}
