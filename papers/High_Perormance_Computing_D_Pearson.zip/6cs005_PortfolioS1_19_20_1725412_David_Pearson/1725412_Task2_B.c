//David Pearson 1725412

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <pthread.h>
//Function declarations 
void header (); 
void clear (); 
void populateMatrix(int a,int b);
void *tSolve (void *arg);
int time_difference(struct timespec *start,
                    struct timespec *finish,
                    long long int *difference);
//Struct declaration
typedef struct { 
    int start; 
    int numThreads; 
} Tmagic;


//Variables
#define N 2000
#define P 2000
#define M 2000
int A[N][P], B[P][M], C[N][M];
int threads;
//Main program
int main() {

    //Populate Matrix A & B
    populateMatrix(N,M);  
    clear(); 
    header();
    //How many threads
    printf("\n\tEnter number of threads = "); 
    scanf("%d",&threads);
    long long int totTimeA = 0;
    for(int s = 0; s < 5; s++){
        //If 1 thread then run it sequentially
        if (threads == 1){
            struct timespec start,finish;
            long long int time_elapsed;
            clock_gettime(CLOCK_MONOTONIC, &start);     
            for (int k = 0; k < N; k++) {
                for (int i = 0; i < M; i++) {
                        for (int j = 0; j < P; j++) {
                                C[i][j] += A[i][k] * B[k][j];
                        }
                }
            }
            clock_gettime(CLOCK_MONOTONIC, &finish); 
            time_difference(&start, &finish, &time_elapsed);
            totTimeA += time_elapsed;
            printf("\tTime taken to complete with %d Threads was = %lf seconds  \n",threads,(totTimeA/1.0e9));
        }  else {
            //if more than 1 thread then multi thread it
            struct timespec start,finish;
            long long int time_elapsed;
            clock_gettime(CLOCK_MONOTONIC, &start); 
            pthread_t tIDs[threads]; 
            pthread_attr_t attr[threads]; 
            for (int c = 0; c < threads; c++){
                pthread_attr_t attr; 
                pthread_attr_init(&attr); 
                Tmagic args = {c, threads};
                pthread_create(&tIDs[c],&attr,tSolve,&args); 
            }     
            //rejoin the threads
            for (size_t i = 0; i < threads; i++) {
                pthread_join(tIDs[i], NULL);
            }
            //return time taken
            clock_gettime(CLOCK_MONOTONIC, &finish); 
            time_difference(&start, &finish, &time_elapsed);
            totTimeA += time_elapsed;
            printf("\tTime taken to complete with %d Threads was = %0.4lf seconds  \n",threads,(time_elapsed/1.0e9));
        }
    }
    long long int avgTimeA = totTimeA/5; 
    printf("\tAverage time taken to complete with %d Threads was = %0.4lf seconds  \n",threads,(avgTimeA/1.0e9));
}
//Function returns header at the top of the page 
void header () { 
    printf("\n\tDavid Pearson 1725412"); 
    printf("\n\t6CS005\n\tHigh Performance Computing"); 
    printf("\n\tMatrix Multiplication 2B\n"); 
}
//Function to clear the screen 
void clear() { 
    printf("\033[H\033[J"); 
}
//function to populate the Matrix
void populateMatrix(int a,int b){
    for (int x = 0; x < a; x++){
        for (int y = 0; y < b; y++){
            int r = rand() % 100 + 1;
            int t = rand() % 100 + 1;
            A[x][y] = r;
            B[x][y] = t;
        }
    }
}

//function for time differnce
int time_difference(struct timespec *start,
                    struct timespec *finish,
                    long long int *difference){

long long int ds = finish->tv_sec - start->tv_sec;
long long int dn = finish->tv_nsec - start->tv_nsec;

if(dn < 0){
    ds--;
    dn += 1000000000;
    }
    *difference = ds * 1000000000 + dn;
    return !(*difference > 0);
}
//Thread based solve function 
void *tSolve (void *args){ 
    Tmagic x = *((Tmagic *)args);
    int u, temp[N];
    //looping through the collumns 1 per thread, stepping the number of threads each time
    for (int j = x.start; j < M; j += x.numThreads){
        //looping thtough the rows of matrix B and assigning to the temp matrix 
        for (int k = 0; k < P; k++){
            temp[k] = B[k][j];
        }
        //looping thorugh thr rows of matrix A
        for (int i = 0; i < N; i++){
            u = 0;
            //loop through and perfrom multiplication
            for (int k = 0; k < P; k++){
                u += A[i][k] * temp[k];
            }
            //assign the data to the C matrix
            C[i][j] = u;
        }
    }
}