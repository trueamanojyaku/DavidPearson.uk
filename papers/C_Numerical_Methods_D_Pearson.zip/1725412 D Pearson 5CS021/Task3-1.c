#include <stdio.h> 
#include <stdlib.h>
#include <pthread.h>
#include "lodepng.h"

//function declarations
void header ();
void clear ();
void *tFilterNeg (void *arg);
void *tFilterRed (void *arg);
void *tFilterGreen (void *arg);
void *tFilterBlue (void *arg);

//Structure definition
struct pixel {
	unsigned char r; //red value
	unsigned char g; //green value
	unsigned char b; //blue value
	unsigned char t; //transparency value
};
struct block {
	long start;
	long end;
};

//Variables
	unsigned int error;
	unsigned int encError;
	unsigned char* image;
	unsigned int width;
	unsigned int height;
	int numThreads = 0;
	struct pixel *allPixels;
	int filter = 0;

int main(int argc, char **argv ){
	//clear the screen and add the header
	clear ();
	header ();	
	
	//ask the user how many threads
	printf("\n\tEnter number of threads = ");
	scanf("%d",&numThreads);
	
	clear ();
	header ();
	//ask the user which filter they would like
	printf("\n\tEnter select the filter you would like to apply = ");
	printf("\n\t(1) = negative  : This will reverse the RGB values for each pixel");
	printf("\n\t(2) = Red       : This will increase the R value for each pixel by 50%%");
	printf("\n\t(3) = Green     : This will increase the G value for each pixel by 50%%");
	printf("\n\t(4) = Blue      : This will increase the B value for each pixel by 50%%");
	printf("\n\tEnter a number = ");
	scanf("%d",&filter);

	//read in the file	
	error = lodepng_decode32_file(&image, &width, &height, argv[1]);
	if(error){
		printf("error %u: %s\n", error, lodepng_error_text(error));
	}
	
	//find out how many pixels we are dealing with
	long pixelCount = width*height;

	//create a list of pixel type structs, using malloc to assign the size
	//struct pixel *allPixels=malloc(pixelCount*sizeof(struct pixel));
	allPixels=malloc(pixelCount*sizeof(struct pixel));
	
	//create threat start and end points based on num of pixels and threads
	struct block tpoints[numThreads];
	long chunk = pixelCount / numThreads;
	long start = 0;
	for (int c = 0; c<(numThreads-1); c++) {
		tpoints[c].start = start;
		tpoints[c].end = start + chunk;
		start += chunk;
	}	
	tpoints[numThreads-1].start = (tpoints[numThreads-2].end);
	tpoints[numThreads-1].end = pixelCount;
											

	//populate the pixel structs from the image list
	for(long i = 0; i < pixelCount; i++){
		allPixels[i].r = image[0+(i*4)];
		allPixels[i].g = image[1+(i*4)];
		allPixels[i].b = image[2+(i*4)];
		allPixels[i].t = image[3+(i*4)];	
	}


	//thread stuff
	//create an array of thread id's
	pthread_t tIDs[numThreads];
	
	//create an array of thread attr's
	pthread_attr_t attr[numThreads];

	//initialise each thread
	for (int c = 0; c < numThreads; c++){
		pthread_attr_init(&attr[c]);
	}
	
	//set each thread going
	for (int c = 0; c < numThreads; c++){
		if (filter == 1){
		pthread_create(&tIDs[c],&attr[c],tFilterNeg,&tpoints[c]);
		}
		if (filter == 2){
		pthread_create(&tIDs[c],&attr[c],tFilterRed,&tpoints[c]);
		}
		if (filter == 3){
		pthread_create(&tIDs[c],&attr[c],tFilterGreen,&tpoints[c]);
		}
		if (filter == 4){
		pthread_create(&tIDs[c],&attr[c],tFilterBlue,&tpoints[c]);
		}
	}

	//re join all threads
	for (int c = 0; c < numThreads; c++){
		pthread_join(tIDs[c],NULL);
	}

	//re-build the image list
		for(long i = 0; i <pixelCount; i++){
		image[0+(i*4)] = allPixels[i].r;
		image[1+(i*4)] = allPixels[i].g;
		image[2+(i*4)] = allPixels[i].g;
		image[3+(i*4)] = allPixels[i].t;
	}

	//re encode the png file
	encError = lodepng_encode32_file(argv[2], image, width, height);
	if(encError){
		printf("error %u: %s\n", error, lodepng_error_text(encError));
	}
	free(image);		
	return 0;
}


//Function returns header at the top of the page
void header () {
	printf("\n\tDavid Pearson 1725412");
	printf("\n\t5CS021\n\tNumerical Methods in C");
	printf("\n\t3.1 Single Pixel\n\n");
}

//Function to clear the screen
void clear() {
    printf("\033[H\033[J");
}

//Thread based solve function
void *tFilterNeg (void *arg){
	struct block *tpoints = (struct block*) arg;
	for (long s = tpoints->start; s < tpoints->end; s++){												
		allPixels[s].r = 255-allPixels[s].r;
		allPixels[s].g = 255-allPixels[s].g;
		allPixels[s].b = 255-allPixels[s].b;
	}	
	pthread_exit(0);
}
//Thread based solve function
void *tFilterRed (void *arg){
	struct block *tpoints = (struct block*) arg;
	for (long s = tpoints->start; s < tpoints->end; s++){												
		allPixels[s].r = (((255-allPixels[s].r)/2)+allPixels[s].r);
	}	
	pthread_exit(0);
}
//Thread based solve function
void *tFilterGreen (void *arg){
	struct block *tpoints = (struct block*) arg;
	for (long s = tpoints->start; s < tpoints->end; s++){												
		allPixels[s].g = (((255-allPixels[s].g)/2)+allPixels[s].g);
	}	
	pthread_exit(0);
}
//Thread based solve function
void *tFilterBlue (void *arg){
	struct block *tpoints = (struct block*) arg;
	for (long s = tpoints->start; s < tpoints->end; s++){												
		allPixels[s].b = (((255-allPixels[s].b)/2)+allPixels[s].b);
	}	
	pthread_exit(0);
}
