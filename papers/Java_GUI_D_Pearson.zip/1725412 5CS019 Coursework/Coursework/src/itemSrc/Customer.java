package itemSrc;

/**
 * This class describes a customer object
 * @author David Pearson 1725412
 * @param name 	This is the customers name
 * @param rId	This is ID of the Rucksack that the customer is looking for
 * @param queueing Shows if the customer is in the queue or not
 * @param customerNumber this is the position of the customer in the queue, 
 * 			automatically, sequentially generated as each new customer object is created.
 */

public class Customer
{
	/**
	 * Instance variables 
	 */
	private static int sequence = 1;
	private String name;
	private String rId;
	private int customerNumber;
	private boolean queueing = false;

	/**
	 * Constructor for a Customer Object, requires a String for name
	 * and a String for the rId.
	 * 
	 * @param name This is the customers name
	 * @param rId This is ID of the Rucksack that the customer is looking for
	 */
    public Customer(String name, String rId) {
    	customerNumber = sequence;
    	sequence++;
    	this.name = name;
    	this.rId = rId;
	}

    /**
     * Gets the name of the customer
     * 
     * @return 'name' of the customer object
     */
	public String getName() {		
		return name;	
	}
	
	/**
	 * Gets the rucksack ID associated with the customer
	 * 
	 * @return 'rId' The ID code for the Rucksack
	 */
	public String getrId() {		
		return rId;  	
	}
	
	/**
	 * Gets the customerNumber
	 * 
	 * @return 'customerNumber' of the customer
	 */
	public int getCustomerNumber() {		
		return customerNumber;	
	}
	
	/**
	 * Tells you if the customer if queueing
	 * 
	 * @return True if they are, false if they are not
	 */
	public boolean isQueueing(){		
		return queueing;	
	}
	
	/**
	 * Sets the name of the customer
	 * 
	 * @param name of the customer 
	 */
	public void setName(String name) {
		this.name = name;		
	}
	
	/**
	 * Sets the Rucksack ID that the customer is looking for
	 * 
	 * @param rId for the Rucksack object
	 */
	public void setrId(String rId) {
		this.rId = rId;
	}
	
	/**
	 * Sets if the customer is queueing or not
	 * 
	 * @param queueing = true if they are, false if they are not
	 */
	public void setQueueing(boolean queueing) {
		this.queueing = queueing;
	}
	
	/**
	 * This will override the automatic customer number generated
	 * within the constructor
	 * 
	 * @param customerNumber is new customernumber for the customer
	 */
	public void setCustomerNumber(int customerNumber) {
		this.customerNumber = customerNumber;
	}
	

	/**
	 * This overrides the existing toString method
	 * 
	 * @return Customer details in a string
	 */
	@Override
	public String toString() {
		return "Customer [name is :"+name+", rID = "+rId+", qNum = "+customerNumber+", queueing : "+queueing+"]";
	}

}
