//David Pearson 1725412

#include <stdio.h>

int main() {
	int A,B,C,D;
	int tempC, tempB;

	A = 10;
	B = 4;
	C = 6;
	D = 4;

	tempB = B;
	tempC = C;

	B = A + C;
	B = C + D;
	C = B + D;

	B = tempB;
	C = tempC;	


}
