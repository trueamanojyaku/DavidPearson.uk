package itemTests;

import static org.junit.Assert.*;

import org.junit.Test;

import itemSrc.*;

/**
 * JUnit test class for the RucksackMap class
 * @author David Pearson 1725412
 */

public class RucksackMapTest {

	RucksackMap rucksackList;
	/**
	 * This tests the rucksackmap constructor
	 */
	@Test
	public void testRucksackMap() {
		rucksackList = new RucksackMap();
		assertFalse(rucksackList.hasRucksack()==true);
		Rucksack p = new Rucksack("lt64s", 2, 5, 4, 3,1);
		Rucksack p2 = new Rucksack("ntqx", 1, 3, 2, 3,1);
		rucksackList.addDetails(p2);
		rucksackList.addDetails(p);
		assertEquals(rucksackList.getNumberOfEntries(),2,0);
		assertEquals(rucksackList.findRucksack("ntqx"),p2);
	}

	/**
	 * This tests the addDetails method, by adding two rucksack objects
	 * to a Rucksack Map
	 */
	@Test
	public void testAddDetails() {
		rucksackList = new RucksackMap();
		Rucksack p = new Rucksack("lt64s", 2, 5, 4, 3,1);
		Rucksack p2 = new Rucksack("ntqx", 1, 3, 2, 3,1);
		rucksackList.addDetails(p2);

		assertEquals(rucksackList.getNumberOfEntries(),1,0);
		rucksackList.addDetails(p);
		assertEquals(rucksackList.findRucksack("lt64s"),p);
		assertEquals(rucksackList.getNumberOfEntries(),2,0);
	}

	/**
	 * This tests the hasRucksack method checking if the TreeMap is
	 * empty or not
	 */
	@Test
	public void testHasRucksack() {
		rucksackList = new RucksackMap();
		assertFalse(rucksackList.hasRucksack());
		Rucksack p = new Rucksack("lt64s", 2, 5, 4, 3,1);
		Rucksack p2 = new Rucksack("ntqx", 1, 3, 2, 3,1);
		rucksackList.addDetails(p2);
		assertTrue(rucksackList.hasRucksack());
		rucksackList.addDetails(p);
		assertTrue(rucksackList.getNumberOfEntries()==2);
	}

	/**
	 * This Tests the getNumberOfEntries is working as expected
	 */
	@Test
	public void testGetNumberOfEntries() {
		rucksackList = new RucksackMap();
		assertTrue(rucksackList.getNumberOfEntries()==0);
		Rucksack p = new Rucksack("lt64s", 2, 5, 4, 3,1);
		Rucksack p2 = new Rucksack("ntqx", 1, 3, 2, 3,1);
		rucksackList.addDetails(p2);
		assertTrue(rucksackList.getNumberOfEntries()>0);
		rucksackList.addDetails(p);
		assertTrue(rucksackList.getNumberOfEntries()==2);
	}

	/**
	 * This tests the AllGone Method by adding to rucksacks
	 * to the map, then setting them to collected
	 * then calling the method
	 */
	@Test
	public void testAllGone() {
		rucksackList = new RucksackMap();
		Rucksack p = new Rucksack("lt64s", 2, 5, 4, 3,1);
		Rucksack p2 = new Rucksack("ntqx", 1, 3, 2, 3,1);
		rucksackList.addDetails(p2);
		rucksackList.setCollected(p2);
		assertTrue(rucksackList.allGone());
		rucksackList.addDetails(p);
		assertFalse(rucksackList.allGone());

	}

	/**
	 * This tests that the number of values output in the ListDetails
	 * method is correct
	 */
	@Test
	public void testListDetails() {
		rucksackList = new RucksackMap();
		Rucksack p2 = new Rucksack("ntqx", 1, 3, 2, 3,1);
		rucksackList.addDetails(p2);
		String details [] = rucksackList.listDetails().split(",");
		assertEquals(details.length,7,0);
	}

	/**
	 * This tests the setCollected method
	 */
	@Test
	public void testSetCollected() {
		rucksackList = new RucksackMap();
		Rucksack p = new Rucksack("lt64s", 2, 5, 4, 3,1);
		Rucksack p2 = new Rucksack("ntqx", 1, 3, 2, 3,1);
		rucksackList.addDetails(p2);
		rucksackList.addDetails(p);
		rucksackList.setCollected(p2);
		assertTrue(rucksackList.hasRucksack());
		rucksackList.setCollected(p);
		assertTrue(rucksackList.allGone());
	}

	/**
	 * This tests that we can list uncollected items
	 *
	 */
	@Test
	public void testListUncollected() {
		rucksackList = new RucksackMap();
		Rucksack p = new Rucksack("lt64s", 2, 5, 4, 3,1);
		Rucksack p2 = new Rucksack("ntqx", 1, 3, 2, 3,1);
		rucksackList.addDetails(p2);
		rucksackList.addDetails(p);
		rucksackList.setCollected(p2);
		assertEquals(rucksackList.listUncollected(),"Rucksack [id=lt64s, days=2, length=5, width=4, height=3, weight=1, collected:false]/n");
	}

	/**
	 * this tests whether we can find a parcel that matches a certain id
	 */
	@Test
	public void testFindParcel() {
		rucksackList = new RucksackMap();
		Rucksack p = new Rucksack("lt64s", 2, 5, 4, 3,1);
		Rucksack p2 = new Rucksack("ntqx", 1, 3, 2, 3,1);
		rucksackList.addDetails(p2);
		rucksackList.addDetails(p);
		assertNotEquals(rucksackList.findRucksack("ntqx"), p);
		assertEquals(rucksackList.findRucksack("ntqx"), p2);
	}

}
