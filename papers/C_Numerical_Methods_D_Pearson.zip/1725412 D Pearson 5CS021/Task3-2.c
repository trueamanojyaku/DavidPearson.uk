#include <stdio.h> 
#include <stdlib.h>
#include <pthread.h>
#include "lodepng.h"

//function declarations
void header ();
void clear ();
void *tBlur(void *arg);

//Structure definition
struct pixel {
	unsigned char r; //red value
	unsigned char g; //green value
	unsigned char b; //blue value
	unsigned char t; //transparency value
};

struct block {
	long start;
	long end;
};

//Variables
	unsigned int error;
	unsigned int encError;
	unsigned char* image;
	unsigned int width;
	unsigned int height;
	int numThreads = 0;
	struct pixel **OI;
	struct pixel **MI;


int main(int argc, char **argv ){
	//clear the screen and add the header
	clear ();
	header ();	

	//ask the user how many threads
	printf("\n\tEnter number of threads = ");
	scanf("%d",&numThreads);
		
	clear ();
	header ();

	//read in the file	
	error = lodepng_decode32_file(&image, &width, &height, argv[1]);
	if(error){
		printf("error %u: %s\n", error, lodepng_error_text(error));
	}

	//find out how many pixels we are dealing with
	long pixelCount = width*height;
	
	OI=malloc((sizeof(struct pixel)*height)*width);
		for (int i = 0; i < height; i++){
			OI[i] = malloc(sizeof(struct pixel)*width);	
		}

	MI=malloc((sizeof(struct pixel)*height)*width);
		for (int i = 0; i < height; i++){
			MI[i] = malloc(sizeof(struct pixel)*width);	
		}

	//populate the pixel structs from the image list
	for(long row=0; row < height; row++){
		for(long col=0; col < width; col++){
			OI[row][col].r = image[0+(col*4)+(4*(width*row))];
			OI[row][col].g = image[1+(col*4)+(4*(width*row))];
			OI[row][col].b = image[2+(col*4)+(4*(width*row))];
			OI[row][col].t = image[3+(col*4)+(4*(width*row))];
		}
	}
	//BLUR
	//top left
	MI[0][0].r = ((OI[0][0].r + OI[0][1].r + OI[1][0].r + OI[1][1].r)/4);
	MI[0][0].g = ((OI[0][0].g + OI[0][1].g + OI[1][0].g + OI[1][1].g)/4);
	MI[0][0].b = ((OI[0][0].b + OI[0][1].b + OI[1][0].b + OI[1][1].b)/4);
	MI[0][0].t = ((OI[0][0].t + OI[0][1].t + OI[1][0].t + OI[1][1].t)/4);
	//bottom left
	MI[height-1][0].r = ((OI[height-1][0].r + OI[height-1][1].r + OI[height-2][0].r + OI[height-2][1].r)/4);
	MI[height-1][0].g = ((OI[height-1][0].g + OI[height-1][1].g + OI[height-2][0].g + OI[height-2][1].g)/4);
	MI[height-1][0].b = ((OI[height-1][0].b + OI[height-1][1].b + OI[height-2][0].b + OI[height-2][1].b)/4);
	MI[height-1][0].t = ((OI[height-1][0].t + OI[height-1][1].t + OI[height-2][0].t + OI[height-2][1].t)/4);
	//top right
	MI[0][width-1].r = ((OI[0][width-1].r + OI[0][width-2].r + OI[1][width-1].r + OI[1][width-2].r)/4);
	MI[0][width-1].g = ((OI[0][width-1].g + OI[0][width-2].g + OI[1][width-1].g + OI[1][width-2].g)/4);
	MI[0][width-1].b = ((OI[0][width-1].b + OI[0][width-2].b + OI[1][width-1].b + OI[1][width-2].b)/4);
	MI[0][width-1].t = ((OI[0][width-1].t + OI[0][width-2].t + OI[1][width-1].t + OI[1][width-2].t)/4);
	//bottom right
	MI[height-1][width-1].r = ((OI[height-1][width-1].r + OI[height-1][width-2].r + OI[height-2][width-1].r + OI[height-2][width-2].r)/4);
	MI[height-1][width-1].g = ((OI[height-1][width-1].g + OI[height-1][width-2].g + OI[height-2][width-1].g + OI[height-2][width-2].g)/4);
	MI[height-1][width-1].b = ((OI[height-1][width-1].b + OI[height-1][width-2].b + OI[height-2][width-1].b + OI[height-2][width-2].b)/4);
	MI[height-1][width-1].t = ((OI[height-1][width-1].t + OI[height-1][width-2].t + OI[height-2][width-1].t + OI[height-2][width-2].t)/4);
	
	//top and bottom edge
	for (long c = 1; c < width-1; c++){
		//top
		MI[0][c].r = ((OI[0][c-1].r + OI[0][c].r + OI[0][c+1].r + OI[1][c-1].r + OI[1][c].r + OI[1][c+1].r)/6);
		MI[0][c].g = ((OI[0][c-1].g + OI[0][c].g + OI[0][c+1].g + OI[1][c-1].g + OI[1][c].g + OI[1][c+1].g)/6);
		MI[0][c].b = ((OI[0][c-1].b + OI[0][c].b + OI[0][c+1].b + OI[1][c-1].b + OI[1][c].b + OI[1][c+1].b)/6);
		MI[0][c].t = ((OI[0][c-1].t + OI[0][c].t + OI[0][c+1].t + OI[1][c-1].t + OI[1][c].t + OI[1][c+1].t)/6);
		//bottom
		MI[height-1][c].r = ((OI[height-1][c-1].r + OI[height-1][c].r + OI[height-1][c+1].r + OI[height-2][c-1].r + OI[height-2][c].r + OI[height-2][c+1].r)/6);
		MI[height-1][c].g = ((OI[height-1][c-1].g + OI[height-1][c].g + OI[height-1][c+1].g + OI[height-2][c-1].g + OI[height-2][c].g + OI[height-2][c+1].g)/6);
		MI[height-1][c].b = ((OI[height-1][c-1].b + OI[height-1][c].b + OI[height-1][c+1].b + OI[height-2][c-1].b + OI[height-2][c].b + OI[height-2][c+1].b)/6);
		MI[height-1][c].t = ((OI[height-1][c-1].t + OI[height-1][c].t + OI[height-1][c+1].t + OI[height-2][c-1].t + OI[height-2][c].t + OI[height-2][c+1].t)/6);
	}

	//left and right edge
	for (long c = 1; c < height-1; c++) {
		//left
		MI[c][0].r = ((OI[c-1][0].r + OI[c][0].r + OI[c+1][0].r + OI[c-1][1].r + OI[c][1].r + OI[c+1][1].r)/6);
		MI[c][0].g = ((OI[c-1][0].g + OI[c][0].g + OI[c+1][0].g + OI[c-1][1].g + OI[c][1].g + OI[c+1][1].g)/6);
		MI[c][0].b = ((OI[c-1][0].b + OI[c][0].b + OI[c+1][0].b + OI[c-1][1].b + OI[c][1].b + OI[c+1][1].b)/6);
		MI[c][0].t = ((OI[c-1][0].t + OI[c][0].t + OI[c+1][0].t + OI[c-1][1].t + OI[c][1].t + OI[c+1][1].t)/6);
		//right
		MI[c][width-1].r = ((OI[c-1][width-1].r + OI[c][width-1].r + OI[c+1][width-1].r + OI[c-1][width-2].r + OI[c][1].r + OI[c+1][width-2].r)/6);
		MI[c][width-1].g = ((OI[c-1][width-1].g + OI[c][width-1].g + OI[c+1][width-1].g + OI[c-1][width-2].g + OI[c][1].g + OI[c+1][width-2].g)/6);
		MI[c][width-1].b = ((OI[c-1][width-1].b + OI[c][width-1].b + OI[c+1][width-1].b + OI[c-1][width-2].b + OI[c][1].b + OI[c+1][width-2].b)/6);
		MI[c][width-1].t = ((OI[c-1][width-1].t + OI[c][width-1].t + OI[c+1][width-1].t + OI[c-1][width-2].t + OI[c][1].t + OI[c+1][width-2].t)/6);
	}


	//create threat start and end points based on num of pixels and threads
	struct block tpoints[numThreads];
	long chunk = height / numThreads;
	long start = 1;
	for (int c = 0; c<(numThreads-1); c++) {
		tpoints[c].start = start;
		tpoints[c].end = start + chunk;
		start += chunk;
	}	
	tpoints[numThreads-1].start = (tpoints[numThreads-2].end);
	tpoints[numThreads-1].end = height-1;
	
	//thread stuff
	//create an array of thread id's
	pthread_t tIDs[numThreads];
	
	//create an array of thread attr's
	pthread_attr_t attr[numThreads];

	//initialise each thread
	for (int c = 0; c < numThreads; c++){
		pthread_attr_init(&attr[c]);
	}
	
	//set each thread going
	for (int c = 0; c < numThreads; c++){
		pthread_create(&tIDs[c],&attr[c],tBlur,&tpoints[c]);
		}
		
	//re join all threads
	for (int c = 0; c < numThreads; c++){
		pthread_join(tIDs[c],NULL);
	}

	for(long row=0; row < height; row++){
		for(long col=0; col < width; col++){
			image[0+(col*4)+(4*(width*row))] = MI[row][col].r;
			image[1+(col*4)+(4*(width*row))] = MI[row][col].g;
			image[2+(col*4)+(4*(width*row))] = MI[row][col].b;
			image[3+(col*4)+(4*(width*row))] = MI[row][col].t;
		}
	}

	//re encode the png file
	encError = lodepng_encode32_file(argv[2], image, width, height);
	if(encError){
		printf("error %u: %s\n", error, lodepng_error_text(encError));
	}
	free(image);		
	return 0;

}


//Function returns header at the top of the page
void header () {
	printf("\n\tDavid Pearson 1725412");
	printf("\n\t5CS021\n\tNumerical Methods in C");
	printf("\n\t3.2 Multi Pixel\n\n");
}

//Function to clear the screen
void clear() {
    printf("\033[H\033[J");
}

//Thread based solve function
void *tBlur(void *arg){
	struct block *tpoints = (struct block*) arg;
	for (long i = tpoints->start; i < tpoints->end; i++){												
		for (long c = 1; c < width-1; c++){
			MI[i][c].r = ((OI[i-1][c-1].r + OI[i-1][c].r + OI[i-1][c+1].r + OI[i][c-1].r + OI[i][c].r + OI[i][c+1].r + OI[i+1][c-1].r + OI[i+1][c].r + OI[i+1][c+1].r)/9);
			MI[i][c].g = ((OI[i-1][c-1].g + OI[i-1][c].g + OI[i-1][c+1].g + OI[i][c-1].g + OI[i][c].g + OI[i][c+1].g + OI[i+1][c-1].g + OI[i+1][c].g + OI[i+1][c+1].g)/9);
			MI[i][c].b = ((OI[i-1][c-1].b + OI[i-1][c].b + OI[i-1][c+1].b + OI[i][c-1].b + OI[i][c].b + OI[i][c+1].b + OI[i+1][c-1].b + OI[i+1][c].b + OI[i+1][c+1].b)/9);
			MI[i][c].t = ((OI[i-1][c-1].t + OI[i-1][c].t + OI[i-1][c+1].t + OI[i][c-1].t + OI[i][c].t + OI[i][c+1].t + OI[i+1][c-1].t + OI[i+1][c].t + OI[i+1][c+1].t)/9);
		}
	}	
	pthread_exit(0);
}

