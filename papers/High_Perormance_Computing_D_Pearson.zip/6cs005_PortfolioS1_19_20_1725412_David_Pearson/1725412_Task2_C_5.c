//David Pearson 1725412

/*
// this is a list of hash strings that can be used for testing purposes

peo
\$6\$AS\$wAmVirDCKTfB.CnpkHvO2YyiLQFGdFp.yGsJnR3V3LKhgFwD.bxJKQTlgu/2H5xkvIcsAq3zU4e1NILL4S5ek/
bbb
\$6\$AS\$hYQ0YlIrqlwPiyk6fXVZon1I8OXCSI6UVKwQqRvt0evjFVCdWILvcARvP4HS4hf3jswXQcQIaY6is3THpyv7r/
zzz
\$6\$AS\$IycSYcwdlSQZhy03dx0.ybpp8/gt55yu9uAS3emkuhMdZFxlG7mrHmq.EIKUtFB9TeEfVEBGk0WPQIf.yEsdC.
DP81
\$6\$AS\$5zUK5dO8Ii1g5C6b.7cYyxp71GNV0sTcEnGdp3C7RhDNnMvVTZLQxb.5oKxfivFQ4GoNlAnChc/zXPMKgEZ5c0
PEO42
\$6\$AS\$C8c9hqKVmWbyxG9pru0mMGAV3ZGtShKS8f4MheWLxqo1Xp9meFhXLHiLhPGCqBb73gvBBWtCQh7rdYmApveuT.
LG20
\$6\$AS\$tK.irhI1GFVPSqBG3kXJ43ZrVmvSKoFX.UZGeKoyl6GxeSx0maTdngNeY6nTfqQ4fYRp1C94aFJu2WGsk2af.0 
ABC12
\$6\$AS\$.Lb98VbQhR0UpKS47MHfBeBfaUv2xOVdxq5melSrsQmrwf.zwvsHJXQrWnyO62J.fsiKymRLZ9vOXs2nwl4L6.
*/

// Libraries that need to be loaded 
#include <stdio.h> 
#include <stdlib.h> 
#include <pthread.h> 
#include <string.h>
#include <crypt.h>
#include <unistd.h>
#include <time.h>

//function declarations 
void header (); 
void clear (); 
int fileLength(char *filename);
void addwords(char* filename, int start, int end);
int howManyThreads();
void substr(char *dest, char *src, int start, int length);
void *tSolve (void *arg);
int time_difference(struct timespec *start,
                    struct timespec *finish,
                    long long int *difference);

//Struct declarations 
struct block { 
    long indexStart; 
    long end; 
};

struct pair { 
    char key[255]; 
    char pass[3]; 
};

//Variable declarations 
int threads = 0; 
long totalwords = 0;
struct pair *wordList;
char *salt_and_encrypted;
char salt[7];
char *enc;
int found = 0;

int main(int argc, char *argv[] ){ 
    

    clear(); 
    header(); 
    //check correct number of arguments 
    if (argc != 3){ 
        printf("\tYou have not entered enough arguments\n\tThis requires you to enter the name of the dictionary file to use"); 
    }

    salt_and_encrypted = argv[1];
    substr(salt, salt_and_encrypted, 0, 6);

    printf("\n\tThe key you are attempting to break is");
    printf("\n\t%s",salt_and_encrypted);

    //count how many entries in the dictionary file 
    int A = fileLength(argv[2]); 
    printf("\n\t%s contains %d possible passwords\n",argv[2], A);

    //dynamically allocate memory based on how many words 
    wordList = malloc(sizeof(struct pair)*A);
    
    struct timespec start,finish;
    long long int time_elapsed;
    clock_gettime(CLOCK_MONOTONIC, &start);

    //add the words from the dictionary to the list 
    addwords(argv[2],0,A);
    
    clock_gettime(CLOCK_MONOTONIC, &finish); 
    time_difference(&start, &finish, &time_elapsed);
    printf("\n\ttime taken to load the dictionary into memory = %0.2lf seconds\n",(time_elapsed/1.0e9));
    //How many threads
    threads = howManyThreads();
    long long int totTimeA = 0;

    for (int x = 0; x <10; x++){
            struct timespec start1,finish1;
            long long int time_elapsed1;
            clock_gettime(CLOCK_MONOTONIC, &start1);

            //create chunks based on number of words and number of threads save them as block structs */ 
            struct block tpoints[threads]; 
            long chunk = A / threads; 
            long indexStart = 0; 
            for (int c = 0; c<(threads-1); c++) { 
                tpoints[c].indexStart = indexStart; 
                tpoints[c].end = indexStart + chunk; 
                indexStart += chunk; 
            } 
            tpoints[threads-1].indexStart = (tpoints[threads-2].end); 
            tpoints[threads-1].end = A; 
            /*
            for (int c = 0; c <threads; c++)
                { printf("\n\tthread %d starts at %ld ends at %ld",c,tpoints[c].start,tpoints[c].end); 
            }
            */
            pthread_t tIDs[threads]; 
            pthread_attr_t attr[threads]; 
            for (int c = 0; c < threads; c++){ 
                pthread_attr_init(&attr[c]); 
                pthread_create(&tIDs[c],&attr[c],tSolve,&tpoints[c]); 
            } 
            for (int c = 0; c < threads; c++){ 
                pthread_join(tIDs[c],NULL);
            } 
            clock_gettime(CLOCK_MONOTONIC, &finish1); 
            time_difference(&start1, &finish1, &time_elapsed1); 
            totTimeA += time_elapsed1;
            printf("\n\tRun %d Time taken to find the password using %d Threads = %0.4lf seconds\n",x+1, threads,(time_elapsed1/1.0e9));
            found = 0;
    }
    long long int avgTimeA = totTimeA/10; 
    printf("\tAverage time taken to complete with %d Threads was = %0.4lf seconds  \n",threads,(avgTimeA/1.0e9));
}

//function to get a number of threads greater than 1
int howManyThreads() {
    //ask the user how many threads 
    int x = 0;
    printf("\n\tEnter number of threads = "); 
    scanf("%d",&x);

    if (x == 1){
        printf("\n\tyou have not entered a number greater than 1\n\tHow many threads would you like?");
        scanf("%d",&x);
    }
    return x;
}

/* Function to get the length of the file, by counting the new line characters */ 
int fileLength(char *filename) { 
    int length = 0; 
    FILE *myFile; 
    myFile = fopen(filename, "r"); 
    while(!feof(myFile)) { 
        int ch = fgetc(myFile); 
            if(ch == '\n'){ 
                length++; 
            } 
        } 
    fclose(myFile); 
    return length; 
    }

//Function returns header at the top of the page 
void header () { 
    printf("\n\tDavid Pearson 1725412"); 
    printf("\n\t6CS005\n\tHigh Performance Computing"); 
    printf("\n\tPassword Crack\n"); 
}

//Function to clear the screen 
void clear() { 
    printf("\033[H\033[J"); 
}

//Function to add the entries in the file to the dictionary list
void addwords(char* filename, int start, int end){ 
    FILE *myFile; 
    myFile = fopen(filename,"r"); 
        for(int i = start; i < end; i++){ 
            fscanf(myFile, "%s", wordList[i].pass); 
           // printf("\n\tread in word %s",wordList[i].pass); 
        } 
    fclose(myFile); 
}

void substr(char *dest, char *src, int start, int length){
  memcpy(dest, src + start, length);
  *(dest + length) = '\0';
}


//Thread based solve function 
void *tSolve (void *arg){ 
    char *enc;
    struct block *tpoints = (struct block*) arg; 
        for (long i = tpoints->indexStart; i < tpoints->end; i++) { 
            if(found == 0){
                enc = (char *) crypt(wordList[i].pass, salt);
                if(strcmp(salt_and_encrypted, enc) == 0){
                    printf("\n\tThe decrypted password is %s",wordList[i].pass);
                    found = 1;
                }
            }    
    } pthread_exit(0);
    
}

//function for time differnce
int time_difference(struct timespec *start,
                    struct timespec *finish,
                    long long int *difference){

long long int ds = finish->tv_sec - start->tv_sec;
long long int dn = finish->tv_nsec - start->tv_nsec;

if(dn < 0){
    ds--;
    dn += 1000000000;
    }
    *difference = ds * 1000000000 + dn;
    return !(*difference > 0);
}

