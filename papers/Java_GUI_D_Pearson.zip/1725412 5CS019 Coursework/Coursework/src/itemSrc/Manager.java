package itemSrc;

import java.util.ArrayList;
import java.util.Scanner;

import java.io.*;

/**
 * This class describes the Manager Object It serves as the conduit for most
 * other classes
 *
 * @author David Pearson 1725412
 */

public class Manager {
	/**
	 * instance fields brief overview:
	 *
	 * @param workers      - This is an array that will store the number of workers
	 *                     in the warehouse
	 * @param custQ        - This is a CustomerQueue LinkedList object containing a
	 *                     list of customers
	 * @param allRucksacks - This is a RucksackMap treeMap object containing a list
	 *                     of rucksack orders
	 */
	public Worker[] workers = new Worker[4];
	public CustomerQueue custQ;
	public RucksackMap allRucksacks;

	/**
	 * This is the constructor for a manager object, you pass in a customer queue
	 * and a list of rucksack orders by default it will generate an array to contain
	 * a number of workers
	 */
	public Manager() {
		custQ = new CustomerQueue();
		allRucksacks = new RucksackMap();
	}

	/**
	 * This method initalises the data ready for processing first it reads in the
	 * customer file, followed by the order file.
	 *
	 * The method then cycles through and adds the customers it has loaded to the
	 * customerQueue (10 at a time), as it does this it sets the customer to
	 * "queueing"
	 *
	 * Finally it outputs a print stream of all of the rucksacks that it has loaded
	 *
	 */
	public void initialiseData(String custfile, String ordrfile) {
		readCustFile(custfile);
		readOrderFile(ordrfile);
		for (int i = 0; i < 10; i++) {
			Customer c = custQ.get(i);
			c.setQueueing(true);
		}
		System.out.println("Rucksack details\n" + allRucksacks.listDetails());
	}

	/**
	 * a method to read the customer file by passing in the filename you wish to
	 * read the method uses a "Scanner" object to read the file one line at a time
	 * as long has the a line to read it will: set the variable inputline to the
	 * line being read print out the line that has been read pass the line into the
	 * processCustLine method
	 *
	 * n.b. this method uses a try and catch for any errors
	 */
	public void readCustFile(String filename) {
		try (Scanner scanner = new Scanner(new File(filename))){
			System.out.println("Scanning");
			while (scanner.hasNext()) {
				String inputLine = scanner.nextLine();
				System.out.println(inputLine);
				processCustLine(inputLine);
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	/**
	 * This method is called by the readcustfile method it starts by creating a
	 * String array called parts populated by each element separated by a comma the
	 * method than assigns the elements from within the String array to the
	 * attributes for a customer object It then creates a customer object using
	 * these attributes Finally it adds the customer to the queue initialised by the
	 * Manager object The method has two error catches (1) NumberFormatException (2)
	 * ArrayIndexOutOfBoundsException
	 */
	public void processCustLine(String inputLine) {
		try {
			String parts[] = inputLine.split(",");
			String id = parts[0].trim();
			String pid = parts[1].trim();
			Customer c = new Customer(id, pid);
			custQ.addCustomer(c);
		} catch (NumberFormatException nfe) {
			String error = "Number conversion error in '" + inputLine + "'  - " + nfe.getMessage();
			System.out.println(error);
		} catch (ArrayIndexOutOfBoundsException air) {
			String error = "Not enough items in  : '" + inputLine + "' index position : " + air.getMessage();
			System.out.println(error);
		}
	}

	/**
	 * a method to read the order file by passing in the filename you wish to read
	 * the method uses a "Scanner" object to read the file one line at a time as
	 * long has the a line to read it will: set the variable inputline to the line
	 * being read print out the line that has been read pass the line into the
	 * processOrderLine method
	 *
	 * n.b. this method uses a try and catch for any errors
	 */
	public void readOrderFile(String filename) {
		try (Scanner scanner = new Scanner(new File(filename))) {
			System.out.println("Scanning");
			while (scanner.hasNext()) {
				String inputLine = scanner.nextLine();
				System.out.println(inputLine);
				processOrderLine(inputLine);
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	/**
	 * This method is called by the readorderfile method it starts by creating a
	 * String array called parts populated by each element separated by a comma the
	 * method than assigns the elements from within the String array to the
	 * attributes for a Rucksack object It then creates a Rucksack object using
	 * these attributes Finally it adds the Rucksack to the RucksackMap initialised
	 * by the Manager object The method has two error catches (1)
	 * NumberFormatException (2) ArrayIndexOutOfBoundsException
	 */
	public void processOrderLine(String inputLine) {

		try {
			String parts[] = inputLine.split(",");
			String id = parts[0].trim();
			String dayString = parts[1].trim();
			int days = Integer.parseInt(dayString);
			String lenString = parts[2].trim();
			int l = Integer.parseInt(lenString);
			String widString = parts[3].trim();
			int w = Integer.parseInt(widString);
			String heightString = parts[4].trim();
			int h = Integer.parseInt(heightString);
			String weightString = parts[5].trim();
			int weight = Integer.parseInt(weightString);
			Rucksack p = new Rucksack(id, days, l, h, w, weight);
			allRucksacks.addDetails(p);
		} catch (NumberFormatException nfe) {
			String error = "Number conversion error in '" + inputLine + "'  - " + nfe.getMessage();
			System.out.println(error);
		} catch (ArrayIndexOutOfBoundsException air) {
			String error = "Not enough items in  : '" + inputLine + "' index position : " + air.getMessage();
			System.out.println(error);
		}
	}
}
