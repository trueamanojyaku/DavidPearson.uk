package itemSrc;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Objects;
import java.util.Scanner;
import  java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class GUI extends JFrame {

	GraphicsDevice gd = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice();
	int width = gd.getDisplayMode().getWidth();
	int height = gd.getDisplayMode().getHeight();
	int w = (int) width ;
	int h = (int) height ;


	DateTimeFormatter dtf = DateTimeFormatter.ofPattern("HH:mm:ss");
	DateTimeFormatter ydm = DateTimeFormatter.ISO_LOCAL_DATE;

	Color Customer = new Color(74, 139, 219);
	Color Worker = new Color(255, 255, 100);
	Color Order = new Color(102, 225, 115);
	Color Blank = new Color(180, 104, 255);
	Color btnGreen = new Color(55,214,147);
	Color btnRed = new Color(242,24,24);

	JPanel customerPanel = new JPanel();
		JLabel lblCustTitle = new JLabel();
		JLabel lblCustCount = new JLabel("0");
		JLabel lblCustFile = new JLabel();
		JLabel lblTotalCust = new JLabel();
		JLabel lblCustQFile = new JLabel();
		JLabel lblTotalCustQ = new JLabel("0");
		JTextField txtCustFile = new JTextField();
		JButton btnCustomerLoad = new JButton();
		JButton btnCustSetQueueing = new JButton();

	JPanel workerPanel = new JPanel();
		JLabel lblWorkTitle = new JLabel();
		JLabel lblWrkrName = new JLabel();
		JButton btnAddWrkr = new JButton();
		JButton btnRemoveWrkr = new JButton();
		JTextField txtWrkrName = new JTextField();
			JLabel lblWrkrName1 = new JLabel();
			JButton btbWrkr1State = new JButton();
			JButton btnWrkr1Proc = new JButton();
			JLabel lblWrkrName2 = new JLabel();
			JButton btbWrkr2State = new JButton();
			JButton btnWrkr2Proc = new JButton();
			JLabel lblWrkrName3 = new JLabel();
			JButton btbWrkr3State = new JButton();
			JButton btnWrkr3Proc = new JButton();
			JLabel lblWrkrName4 = new JLabel();
			JButton btbWrkr4State = new JButton();
			JButton btnWrkr4Proc = new JButton();

	JPanel orderPanel = new JPanel();
		JLabel lblOrdrTitle = new JLabel();
		JLabel lblOrdrFile = new JLabel();
		JTextField txtOrdrFile = new JTextField();
		JButton btnOrdrLoad = new JButton();
		JLabel lblUnProcOrdr = new JLabel();
		JLabel lblUnProcOrdrTot = new JLabel("0");
		JLabel lblProcOrdr = new JLabel();
		JLabel lblProcOrdrTot = new JLabel("0");

	JPanel logPanel = new JPanel();
		JLabel lblLogTitle = new JLabel();
		JTextArea txtAreaLog = new JTextArea("Warehouse Log"+"\n");
		JScrollPane txtAreaScroll = new JScrollPane();
		JButton btnLogExport = new JButton();

	int OrdersProc = 0;
	int workerCount = 0;
	Manager m1 = new Manager();

	public GUI() {
		super();

		setTitle("Warehouse System");
		getContentPane().setLayout(new GridLayout(2, 2, 20, 20));
		// Add components;
		initCustomerPanel();
		initWorkerPanel();
		initOrderPanel();
		initBlankPanel();
		setBounds((w-1300)/2,(h-700)/2, 1300, 700);

		// Make visible
		setVisible(true);

		// Make program exit when jframe is closed
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}

	private void initCustomerPanel() {
		customerPanel.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		customerPanel.setBackground(Customer);
		add(customerPanel);

		// Title for the customer panel
		lblCustTitle.setText("CUSTOMERS");
		lblCustTitle.setFont(new Font("Bahnschrift", Font.BOLD, 50));
		lblCustTitle.setHorizontalAlignment(SwingConstants.CENTER);
		c.gridx = 0;
		c.gridy = 0;
		c.gridwidth = 3;
		c.gridheight = 2;
		c.insets = new Insets(5,5,5,5);
		customerPanel.add(lblCustTitle, c);

		// Label telling them to type
		lblCustFile.setText("Please enter the name of the file to load below");
		lblCustFile.setFont(new Font("Bahnschrift", Font.PLAIN, 20));
		lblCustFile.setHorizontalAlignment(SwingConstants.LEFT);
		c.gridx = 0;
		c.gridy = 2;
		c.gridwidth = 3;
		c.gridheight = 1;
		c.insets = new Insets(5,5,5,5);
		customerPanel.add(lblCustFile, c);

		// text box to enter the file name into
		txtCustFile.setColumns(18);
		txtCustFile.setToolTipText("Enter filename here");
		txtCustFile.setFont(new Font("Bahnschrift", Font.PLAIN, 20));
		c.gridx = 0;
		c.gridy = 4;
		c.gridwidth = 2;
		c.gridheight = 1;
		c.insets = new Insets(5,5,5,5);
		customerPanel.add(txtCustFile, c);

		// Button to load in the Customers
		btnCustomerLoad.setText("Load");
		btnCustomerLoad.setFont(new Font("Bahnschrift", Font.PLAIN, 20));
		btnCustomerLoad.addActionListener(e -> {
			String inputText = txtCustFile.getText();
			try {
				Scanner scanner = new Scanner(new File(inputText));
				txtAreaLog.append("Loading Customers" + "\n");
				while (scanner.hasNext()) {
					String inputLine = scanner.nextLine();
					LocalDateTime now = LocalDateTime.now();
					txtAreaLog.append(dtf.format(now)+" Reading . . . " + inputLine + "\n");
					txtAreaLog.setCaretPosition(txtAreaLog.getDocument().getLength());
					m1.processCustLine(inputLine);
				}
				btnCustomerLoad.setEnabled(false);
				scanner.close();
			}
			catch (Exception e1) {
				System.out.println(e1);
				LocalDateTime now = LocalDateTime.now();
				txtAreaLog.append(dtf.format(now)+" the file name you have entered '" + inputText +"' is not vaild"+ "\n");
				txtAreaLog.setCaretPosition(txtAreaLog.getDocument().getLength());
			}
			lblCustCount.setText(Integer.toString(m1.custQ.getQueueSize()));
			GUI.this.revalidate();
		}
		);
		c.gridx = 2;
		c.gridy = 4;
		c.gridwidth = 1;
		c.gridheight = 1;
		c.insets = new Insets(5,5,5,5);
		customerPanel.add(btnCustomerLoad, c);

		// total loaded label
		lblTotalCust.setText("Total Customers Loaded");
		lblTotalCust.setFont(new Font("Bahnschrift", Font.PLAIN, 20));
		c.gridx = 0;
		c.gridy = 6;
		c.gridwidth = 2;
		c.gridheight = 1;
		c.insets = new Insets(5,5,5,5);
		customerPanel.add(lblTotalCust, c);

		// Total loaded Count
		lblCustCount.setFont(new Font("Bahnschrift", Font.BOLD, 20));
		Border border = BorderFactory.createLineBorder(Color.BLACK, 1);
		lblCustCount.setBorder(border);
		c.gridx = 2;
		c.gridy = 6;
		c.gridwidth = 2;
		c.gridheight = 1;
		c.insets = new Insets(5,5,5,5);
		customerPanel.add(lblCustCount, c);

		// total queueing label
		lblCustQFile.setText("Total Customers in Queue");
		lblCustQFile.setFont(new Font("Bahnschrift", Font.PLAIN, 20));
		c.gridx = 0;
		c.gridy = 7;
		c.gridwidth = 2;
		c.gridheight = 1;
		c.insets = new Insets(5,5,5,5);
		customerPanel.add(lblCustQFile, c);

		// Total queueing Count
		lblTotalCustQ.setFont(new Font("Bahnschrift", Font.BOLD, 20));
		lblTotalCustQ.setBorder(border);
		c.gridx = 2;
		c.gridy = 7;
		c.gridwidth = 2;
		c.gridheight = 1;
		c.insets = new Insets(5,5,5,5);
		customerPanel.add(lblTotalCustQ, c);

		// Button to set all customers queuing
		btnCustSetQueueing.setText("Set all queueing");
		btnCustSetQueueing.setFont(new Font("Bahnschrift", Font.PLAIN, 20));
		c.gridx = 1;
		c.gridy = 8;
		c.gridwidth = 1;
		c.gridheight = 1;
		c.insets = new Insets(5,5,5,5);
		customerPanel.add(btnCustSetQueueing, c);
		btnCustSetQueueing.addActionListener(e -> {
			try {
		    	m1.custQ.setAllQueueing();
		    	btnCustSetQueueing.setEnabled(false);
		    	LocalDateTime now = LocalDateTime.now();
		    	txtAreaLog.append(dtf.format(now)+" "+Integer.toString(m1.custQ.getQueueSize()) +
		    			" customers set to queueing" + "\n");
				txtAreaLog.setCaretPosition(txtAreaLog.getDocument().getLength());
			}
			catch (Exception e1) {
				System.out.println(e1);
			}
			lblTotalCustQ.setText(Integer.toString(m1.custQ.getNumberQueueing()));
			GUI.this.revalidate();
		}
		);

	}

	private void initWorkerPanel() {
		workerPanel.setLayout(new GridBagLayout());
		workerPanel.setBackground(Worker);
		GridBagConstraints w = new GridBagConstraints();
		add(workerPanel);

		// Title for the Worker panel
		lblWorkTitle.setText("WORKERS");
		lblWorkTitle.setFont(new Font("Bahnschrift", Font.BOLD, 50));
		lblWorkTitle.setHorizontalAlignment(SwingConstants.CENTER);
		w.gridx = 0;
		w.gridy = 0;
		w.gridwidth = 4;
		w.gridheight = 1;
		w.insets = new Insets(3, 5, 3, 5);
		workerPanel.add(lblWorkTitle, w);

		// Label telling them to type in the name
		lblWrkrName.setText("Please enter the name of the new Worker below (MAX 4)");
		lblWrkrName.setFont(new Font("Bahnschrift", Font.PLAIN, 20));
		lblWrkrName.setHorizontalAlignment(SwingConstants.LEFT);
		w.gridx = 0;
		w.gridy = 1;
		w.gridwidth = 4;
		w.gridheight = 1;
		w.insets = new Insets(3, 5, 3, 5);
		workerPanel.add(lblWrkrName, w);

		// text box to enter the worker name into
		txtWrkrName.setColumns(18);
		txtWrkrName.setToolTipText("Enter Workers Name here");
		txtWrkrName.setFont(new Font("Bahnschrift", Font.PLAIN, 20));
		w.gridx = 0;
		w.gridy = 2;
		w.gridwidth = 2;
		w.gridheight = 1;
		w.insets = new Insets(3, 5, 3, 5);
		workerPanel.add(txtWrkrName, w);

		btnAddWrkr.setText("Add");
		btnAddWrkr.setFont(new Font("Bahnschrift", Font.PLAIN, 20));
		btnAddWrkr.addActionListener(e -> {
			if (workerCount == 0) {
				String inputText = txtWrkrName.getText();
				txtWrkrName.setText("");
				lblWrkrName1.setText(inputText);
				lblWrkrName1.setFont(new Font("Bahnschrift", Font.BOLD, 16));
				w.gridx = 1;
				w.gridy = 3;
				w.gridwidth = 2;
				w.gridheight = 1;
				w.insets = new Insets(3, 5, 3, 5);
				workerPanel.add(lblWrkrName1, w);
				Worker w1 = new Worker(m1.custQ,m1.allRucksacks,inputText);
				m1.workers[0]=w1;
				btbWrkr1State.setText("Open");
				btbWrkr1State.setBackground(btnGreen);
				btbWrkr1State.setFont(new Font("Bahnschrift", Font.PLAIN, 16));
				btbWrkr1State.addActionListener(we1 -> {
		        	if (Objects.equals(btbWrkr1State.getText(), "Open")) {
		        		btbWrkr1State.setText("Closed");
		        		btbWrkr1State.setBackground(btnRed);
						LocalDateTime now = LocalDateTime.now();
						txtAreaLog.append(dtf.format(now)+" Worker " + lblWrkrName1.getText() + " State is now closed" + "\n");
						txtAreaLog.setCaretPosition(txtAreaLog.getDocument().getLength());
		        		btnWrkr1Proc.setEnabled(false);
		        		m1.workers[0].changeState();
		            } else if (Objects.equals(btbWrkr1State.getText(), "Closed")) {
		            	btbWrkr1State.setText("Open");
		            	btbWrkr1State.setBackground(btnGreen);//green
						LocalDateTime now = LocalDateTime.now();
						txtAreaLog.append(dtf.format(now)+" Worker " + lblWrkrName1.getText() + " State is now open" + "\n");
						txtAreaLog.setCaretPosition(txtAreaLog.getDocument().getLength());
		            	btnWrkr1Proc.setEnabled(true);
		                m1.workers[0].changeState();
		            } else 	btbWrkr1State.setText("Open");
		            });
				w.gridx = 2;
				w.gridy = 3;
				w.gridwidth = 1;
				w.gridheight = 1;
				w.insets = new Insets(3,5,3,5);
				workerPanel.add(btbWrkr1State,w);
				btnWrkr1Proc.setText("Process");
				btnWrkr1Proc.setFont(new Font("Bahnschrift", Font.PLAIN, 16));
				btnWrkr1Proc.addActionListener(wp1 -> {
		            // Process customer order
					LocalDateTime now = LocalDateTime.now();
					txtAreaLog.append(dtf.format(now)+" "+m1.workers[0].processOneCustomer()+"\n");
					txtAreaLog.setCaretPosition(txtAreaLog.getDocument().getLength());
					if (m1.allRucksacks.getNumberOfEntries() > 0 ) {
						if (OrdersProc < 30) {
							OrdersProc++;
							lblUnProcOrdrTot.setText(Integer.toString(m1.allRucksacks.getNumberOfEntries()-OrdersProc));
							lblProcOrdrTot.setText(Integer.toString(OrdersProc));
							lblTotalCustQ.setText(Integer.toString(m1.custQ.getQueueSize()));
							GUI.this.revalidate();
						}
					}
		        });
				w.gridx = 3;
				w.gridy = 3;
				w.gridwidth = 1;
				w.gridheight = 1;
				w.insets = new Insets(3,5,3,5);
				workerPanel.add(btnWrkr1Proc,w);
				workerCount++;
				LocalDateTime now = LocalDateTime.now();
				txtAreaLog.append(dtf.format(now)+" Worker " + inputText + " added" + "\n");
				txtAreaLog.append(dtf.format(now)+" Worker count =  " + workerCount+ "\n");
				txtAreaLog.setCaretPosition(txtAreaLog.getDocument().getLength());
				GUI.this.revalidate();
			}
			else if (workerCount == 1) {
				String inputText = txtWrkrName.getText();
				txtWrkrName.setText("");
				lblWrkrName2.setText(inputText);
				lblWrkrName2.setFont(new Font("Bahnschrift", Font.BOLD, 16));
				w.gridx = 1;
				w.gridy = 4;
				w.gridwidth = 2;
				w.gridheight = 1;
				w.insets = new Insets(3, 5, 3, 5);
				workerPanel.add(lblWrkrName2, w);
				Worker w2 = new Worker(m1.custQ,m1.allRucksacks,inputText);
				m1.workers[1]=w2;
				btbWrkr2State.setText("Open");
				btbWrkr2State.setBackground(btnGreen);
				btbWrkr2State.setFont(new Font("Bahnschrift", Font.PLAIN, 16));
				btbWrkr2State.addActionListener(we1 -> {
		        	if (Objects.equals(btbWrkr2State.getText(), "Open")) {
		        		btbWrkr2State.setText("Closed");
		        		btbWrkr2State.setBackground(btnRed);
						LocalDateTime now = LocalDateTime.now();
						txtAreaLog.append(dtf.format(now)+" Worker " + lblWrkrName2.getText() + " State is now closed" + "\n");
						txtAreaLog.setCaretPosition(txtAreaLog.getDocument().getLength());
		        		btnWrkr2Proc.setEnabled(false);
		        		m1.workers[1].changeState();
		            } else if (Objects.equals(btbWrkr2State.getText(), "Closed")) {
		            	btbWrkr2State.setText("Open");
		            	btbWrkr2State.setBackground(btnGreen);//green
						LocalDateTime now = LocalDateTime.now();
						txtAreaLog.append(dtf.format(now)+" Worker " + lblWrkrName2.getText() + " State is now open" + "\n");
						txtAreaLog.setCaretPosition(txtAreaLog.getDocument().getLength());
		            	btnWrkr2Proc.setEnabled(true);
		                m1.workers[1].changeState();
		            } else 	btbWrkr2State.setText("Open");
		            });
				w.gridx = 2;
				w.gridy = 4;
				w.gridwidth = 1;
				w.gridheight = 1;
				w.insets = new Insets(3,5,3,5);
				workerPanel.add(btbWrkr2State,w);
				btnWrkr2Proc.setText("Process");
				btnWrkr2Proc.setFont(new Font("Bahnschrift", Font.PLAIN, 16));
				btnWrkr2Proc.addActionListener(wp2 -> {
					LocalDateTime now = LocalDateTime.now();
					txtAreaLog.append(dtf.format(now)+" "+m1.workers[1].processOneCustomer()+"\n");
					txtAreaLog.setCaretPosition(txtAreaLog.getDocument().getLength());
					if (m1.allRucksacks.getNumberOfEntries() > 0 ) {
						if (OrdersProc < Integer.parseInt(lblCustCount.getText())) {
							OrdersProc++;
							lblUnProcOrdrTot.setText(Integer.toString(m1.allRucksacks.getNumberOfEntries()-OrdersProc));
							lblProcOrdrTot.setText(Integer.toString(OrdersProc));
							lblTotalCustQ.setText(Integer.toString(m1.custQ.getQueueSize()));
							GUI.this.revalidate();
						}
					}
		        });
				w.gridx = 3;
				w.gridy = 4;
				w.gridwidth = 1;
				w.gridheight = 1;
				w.insets = new Insets(3,5,3,5);
				workerPanel.add(btnWrkr2Proc,w);
				workerCount++;
				LocalDateTime now = LocalDateTime.now();
				txtAreaLog.append(dtf.format(now)+" Worker " + inputText + " added" + "\n");
				txtAreaLog.append(dtf.format(now)+" Worker count =  " + workerCount+ "\n");
				txtAreaLog.setCaretPosition(txtAreaLog.getDocument().getLength());
				GUI.this.revalidate();
			}
			else if (workerCount == 2) {
				String inputText = txtWrkrName.getText();
				txtWrkrName.setText("");
				lblWrkrName3.setText(inputText);
				lblWrkrName3.setFont(new Font("Bahnschrift", Font.BOLD, 16));
				w.gridx = 1;
				w.gridy = 5;
				w.gridwidth = 2;
				w.gridheight = 1;
				w.insets = new Insets(3, 5, 3, 5);
				workerPanel.add(lblWrkrName3, w);
				Worker w3 = new Worker(m1.custQ,m1.allRucksacks,inputText);
				m1.workers[2]=w3;
				btbWrkr3State.setText("Open");
				btbWrkr3State.setBackground(btnGreen);
				btbWrkr3State.setFont(new Font("Bahnschrift", Font.PLAIN, 16));
				btbWrkr3State.addActionListener(we1 -> {
		        	if (Objects.equals(btbWrkr3State.getText(), "Open")) {
		        		btbWrkr3State.setText("Closed");
		        		btbWrkr3State.setBackground(btnRed);
						LocalDateTime now = LocalDateTime.now();
						txtAreaLog.append(dtf.format(now)+" Worker " + lblWrkrName3.getText() + " State is now closed" + "\n");
						txtAreaLog.setCaretPosition(txtAreaLog.getDocument().getLength());
		        		btnWrkr3Proc.setEnabled(false);
		        		m1.workers[2].changeState();
		            } else if (Objects.equals(btbWrkr3State.getText(), "Closed")) {
		            	btbWrkr3State.setText("Open");
		            	btbWrkr3State.setBackground(btnGreen);//green
						LocalDateTime now = LocalDateTime.now();
						txtAreaLog.append(dtf.format(now)+" Worker " + lblWrkrName3.getText() + " State is now open" + "\n");
						txtAreaLog.setCaretPosition(txtAreaLog.getDocument().getLength());
		            	btnWrkr3Proc.setEnabled(true);
		                m1.workers[2].changeState();
		            } else 	btbWrkr3State.setText("Open");
		            });
				w.gridx = 2;
				w.gridy = 5;
				w.gridwidth = 1;
				w.gridheight = 1;
				w.insets = new Insets(3,5,3,5);
				workerPanel.add(btbWrkr3State,w);
				btnWrkr3Proc.setText("Process");
				btnWrkr3Proc.setFont(new Font("Bahnschrift", Font.PLAIN, 16));
				btnWrkr3Proc.addActionListener(wp2 -> {
		            // Process customer order
					LocalDateTime now = LocalDateTime.now();
					txtAreaLog.append(dtf.format(now)+" "+m1.workers[2].processOneCustomer()+"\n");
					txtAreaLog.setCaretPosition(txtAreaLog.getDocument().getLength());
					if (m1.allRucksacks.getNumberOfEntries() > 0 ) {
						if (OrdersProc < Integer.parseInt(lblCustCount.getText())) {
							OrdersProc++;
							lblUnProcOrdrTot.setText(Integer.toString(m1.allRucksacks.getNumberOfEntries()-OrdersProc));
							lblProcOrdrTot.setText(Integer.toString(OrdersProc));
							lblTotalCustQ.setText(Integer.toString(m1.custQ.getQueueSize()));
							GUI.this.revalidate();
						}
					}
		        });
				w.gridx = 3;
				w.gridy = 5;
				w.gridwidth = 1;
				w.gridheight = 1;
				w.insets = new Insets(3,5,3,5);
				workerPanel.add(btnWrkr3Proc,w);
				workerCount++;
				LocalDateTime now = LocalDateTime.now();
				txtAreaLog.append(dtf.format(now)+" Worker " + inputText + " added" + "\n");
				txtAreaLog.append(dtf.format(now)+" Worker count =  " + workerCount+ "\n");
				txtAreaLog.setCaretPosition(txtAreaLog.getDocument().getLength());
				GUI.this.revalidate();
			}
			else if (workerCount == 3) {
				String inputText = txtWrkrName.getText();
				txtWrkrName.setText("");
				lblWrkrName4.setText(inputText);
				lblWrkrName4.setFont(new Font("Bahnschrift", Font.BOLD, 16));
				w.gridx = 1;
				w.gridy = 6;
				w.gridwidth = 2;
				w.gridheight = 1;
				w.insets = new Insets(3, 5, 3, 5);
				workerPanel.add(lblWrkrName4, w);
				Worker w4 = new Worker(m1.custQ,m1.allRucksacks,inputText);
				m1.workers[3]=w4;
				btbWrkr4State.setText("Open");
				btbWrkr4State.setBackground(btnGreen);
				btbWrkr4State.setFont(new Font("Bahnschrift", Font.PLAIN, 16));
				btbWrkr4State.addActionListener(we1 -> {
		        	if (Objects.equals(btbWrkr4State.getText(), "Open")) {
		        		btbWrkr4State.setText("Closed");
		        		btbWrkr4State.setBackground(btnRed);
						LocalDateTime now = LocalDateTime.now();
						txtAreaLog.append(dtf.format(now)+" Worker " + lblWrkrName4.getText() + " State is now closed" + "\n");
						txtAreaLog.setCaretPosition(txtAreaLog.getDocument().getLength());
		        		btnWrkr4Proc.setEnabled(false);
		        		m1.workers[3].changeState();
		            } else if (Objects.equals(btbWrkr4State.getText(), "Closed")) {
		            	btbWrkr4State.setText("Open");
		            	btbWrkr4State.setBackground(btnGreen);//green
						LocalDateTime now = LocalDateTime.now();
						txtAreaLog.append(dtf.format(now)+" Worker " + lblWrkrName4.getText() + " State is now open" + "\n");
						txtAreaLog.setCaretPosition(txtAreaLog.getDocument().getLength());
		            	btnWrkr4Proc.setEnabled(true);
		                m1.workers[3].changeState();
		            } else 	btbWrkr4State.setText("Open");
		            });
				w.gridx = 2;
				w.gridy = 6;
				w.gridwidth = 1;
				w.gridheight = 1;
				w.insets = new Insets(3,5,3,5);
				workerPanel.add(btbWrkr4State,w);
				btnWrkr4Proc.setText("Process");
				btnWrkr4Proc.setFont(new Font("Bahnschrift", Font.PLAIN, 16));
				btnWrkr4Proc.addActionListener(wp2 -> {
		            // Process customer order
					LocalDateTime now = LocalDateTime.now();
					txtAreaLog.append(dtf.format(now)+" "+m1.workers[3].processOneCustomer()+"\n");
					txtAreaLog.setCaretPosition(txtAreaLog.getDocument().getLength());
					if (m1.allRucksacks.getNumberOfEntries() > 0 ) {
						if (OrdersProc < Integer.parseInt(lblCustCount.getText())) {
							OrdersProc++;
							lblUnProcOrdrTot.setText(Integer.toString(m1.allRucksacks.getNumberOfEntries()-OrdersProc));
							lblProcOrdrTot.setText(Integer.toString(OrdersProc));
							lblTotalCustQ.setText(Integer.toString(m1.custQ.getQueueSize()));
							GUI.this.revalidate();
						}
					}
		        });
				w.gridx = 3;
				w.gridy = 6;
				w.gridwidth = 1;
				w.gridheight = 1;
				w.insets = new Insets(3,5,3,5);
				workerPanel.add(btnWrkr4Proc,w);
				workerCount++;
				LocalDateTime now = LocalDateTime.now();
				txtAreaLog.append(dtf.format(now)+" Worker " + inputText + " added" + "\n");
				txtAreaLog.append(dtf.format(now)+" Worker count =  " + workerCount+ "\n");
				txtAreaLog.setCaretPosition(txtAreaLog.getDocument().getLength());
				GUI.this.revalidate();
			}
		});
		w.gridx = 2;
		w.gridy = 2;
		w.gridwidth = 1;
		w.gridheight = 1;
		w.insets = new Insets(3, 5, 3, 5);
		workerPanel.add(btnAddWrkr, w);

		// Button to remove a Worker
		btnRemoveWrkr.setText("Remove");
		btnRemoveWrkr.setFont(new Font("Bahnschrift", Font.PLAIN, 20));
		btnRemoveWrkr.addActionListener(wr1 -> {
			if (workerCount == 1) {
				workerPanel.remove(lblWrkrName1);
				workerPanel.remove(btbWrkr1State);
				workerPanel.remove(btnWrkr1Proc);
				workerCount--;
				LocalDateTime now = LocalDateTime.now();
				txtAreaLog.append(dtf.format(now)+" Worker " + lblWrkrName1.getText() + " removed" + "\n");
				txtAreaLog.append(dtf.format(now)+" Worker count =  " + workerCount+ "\n");
				txtAreaLog.setCaretPosition(txtAreaLog.getDocument().getLength());
				GUI.this.revalidate();
				workerPanel.repaint();
				}
			else if (workerCount == 2) {
				workerPanel.remove(lblWrkrName2);
				workerPanel.remove(btbWrkr2State);
				workerPanel.remove(btnWrkr2Proc);
				workerCount--;
				LocalDateTime now = LocalDateTime.now();
				txtAreaLog.append(dtf.format(now)+" Worker " + lblWrkrName2.getText() + " removed" + "\n");
				txtAreaLog.append(dtf.format(now)+" Worker count =  " + workerCount+ "\n");
				txtAreaLog.setCaretPosition(txtAreaLog.getDocument().getLength());
				GUI.this.revalidate();
				workerPanel.repaint();
			}
			else if (workerCount == 3) {
				workerPanel.remove(lblWrkrName3);
				workerPanel.remove(btbWrkr3State);
				workerPanel.remove(btnWrkr3Proc);
				workerCount--;
				LocalDateTime now = LocalDateTime.now();
				txtAreaLog.append(dtf.format(now)+" Worker " + lblWrkrName3.getText() + " removed" + "\n");
				txtAreaLog.append(dtf.format(now)+" Worker count =  " + workerCount+ "\n");
				txtAreaLog.setCaretPosition(txtAreaLog.getDocument().getLength());
				GUI.this.revalidate();
				workerPanel.repaint();
			}
			else if (workerCount == 4) {
				workerPanel.remove(lblWrkrName4);
				workerPanel.remove(btbWrkr4State);
				workerPanel.remove(btnWrkr4Proc);
				workerCount--;
				LocalDateTime now = LocalDateTime.now();
				txtAreaLog.append(dtf.format(now)+" Worker " + lblWrkrName4.getText() + " removed" + "\n");
				txtAreaLog.append(dtf.format(now)+" Worker count =  " + workerCount+ "\n");
				txtAreaLog.setCaretPosition(txtAreaLog.getDocument().getLength());
				GUI.this.revalidate();
				workerPanel.repaint();
			}
		});
		w.gridx = 3;
		w.gridy = 2;
		w.gridwidth = 1;
		w.gridheight = 1;
		w.insets = new Insets(3, 5, 3, 5);
		workerPanel.add(btnRemoveWrkr, w);
	}

	private void initOrderPanel() {
		orderPanel.setLayout(new GridBagLayout());
		GridBagConstraints o = new GridBagConstraints();
		orderPanel.setBackground(Order);
		add(orderPanel);

		// Title for the Order panel
		lblOrdrTitle.setText("ORDERS");
		lblOrdrTitle.setFont(new Font("Bahnschrift", Font.BOLD, 50));
		lblOrdrTitle.setHorizontalAlignment(SwingConstants.CENTER);
		o.gridx = 0;
		o.gridy = 0;
		o.gridwidth = 3;
		o.gridheight = 1;
		o.insets = new Insets(10, 10, 10, 10);
		orderPanel.add(lblOrdrTitle, o);

		lblOrdrFile.setText("Please enter the name of the file to load below");
		lblOrdrFile.setFont(new Font("Bahnschrift", Font.PLAIN, 20));
		lblOrdrFile.setHorizontalAlignment(SwingConstants.LEFT);
		o.gridx = 0;
		o.gridy = 2;
		o.gridwidth = 3;
		o.gridheight = 1;
		o.insets = new Insets(10, 10, 10, 10);
		orderPanel.add(lblOrdrFile, o);

		// text box to enter the file name into
		txtOrdrFile.setColumns(20);
		txtOrdrFile.setToolTipText("Enter filename here");
		txtOrdrFile.setFont(new Font("Bahnschrift", Font.PLAIN, 20));
		o.gridx = 0;
		o.gridy = 4;
		o.gridwidth = 2;
		o.gridheight = 1;
		o.insets = new Insets(10, 10, 10, 10);
		orderPanel.add(txtOrdrFile, o);

		// Button to load in the Orders
		btnOrdrLoad.setText("Load");
		btnOrdrLoad.setFont(new Font("Bahnschrift", Font.PLAIN, 20));
		btnOrdrLoad.addActionListener(e -> {
			String orderTxt = txtOrdrFile.getText();
			try {
				Scanner scanner = new Scanner(new File(orderTxt));
				txtAreaLog.append("Loading Orders" + "\n");
				while (scanner.hasNext()) {
					String inputLine = scanner.nextLine();
					LocalDateTime now = LocalDateTime.now();
					txtAreaLog.append(dtf.format(now)+" Reading . . . " + inputLine + "\n");
					txtAreaLog.setCaretPosition(txtAreaLog.getDocument().getLength());
					m1.processOrderLine(inputLine);
				}
				btnOrdrLoad.setEnabled(false);
				lblUnProcOrdrTot.setText(Integer.toString(m1.allRucksacks.getNumberOfEntries()));
				scanner.close();
			}
			catch (Exception e1) {
				LocalDateTime now = LocalDateTime.now();
				txtAreaLog.append(dtf.format(now)+" the file name you have entered '" + orderTxt +"' is not vaild"+ "\n");
				txtAreaLog.setCaretPosition(txtAreaLog.getDocument().getLength());
			}

			GUI.this.revalidate();
		}
		);
		o.gridx = 2;
		o.gridy = 4;
		o.gridwidth = 1;
		o.gridheight = 1;
		o.insets = new Insets(10, 10, 10, 10);
		orderPanel.add(btnOrdrLoad, o);

		// total unprocessed orders label
		lblUnProcOrdr.setText("Total unprocessed orders");
		lblUnProcOrdr.setFont(new Font("Bahnschrift", Font.PLAIN, 20));
		o.gridx = 0;
		o.gridy = 6;
		o.gridwidth = 2;
		o.gridheight = 1;
		o.insets = new Insets(10, 10, 10, 10);
		orderPanel.add(lblUnProcOrdr, o);

		// total unprocessed orders total
		lblUnProcOrdrTot.setFont(new Font("Bahnschrift", Font.BOLD, 20));
		Border border = BorderFactory.createLineBorder(Color.BLACK, 1);
		lblUnProcOrdrTot.setBorder(border);
		o.gridx = 2;
		o.gridy = 6;
		o.gridwidth = 1;
		o.gridheight = 1;
		o.insets = new Insets(10, 10, 10, 10);
		orderPanel.add(lblUnProcOrdrTot, o);

		// total processed orders label
		lblProcOrdr.setText("Total processed orders");
		lblProcOrdr.setFont(new Font("Bahnschrift", Font.PLAIN, 20));
		o.gridx = 0;
		o.gridy = 7;
		o.gridwidth = 2;
		o.gridheight = 1;
		o.insets = new Insets(10, 10, 10, 10);
		orderPanel.add(lblProcOrdr, o);

		// total processed orders total
		lblProcOrdrTot.setText(Integer.toString(OrdersProc));
		lblProcOrdrTot.setFont(new Font("Bahnschrift", Font.BOLD, 20));
		lblProcOrdrTot.setBorder(border);
		o.gridx = 2;
		o.gridy = 7;
		o.gridwidth = 1;
		o.gridheight = 1;
		o.insets = new Insets(10, 10, 10, 10);
		orderPanel.add(lblProcOrdrTot, o);

	}

	private void initBlankPanel() {
		logPanel.setLayout(new GridBagLayout());
		GridBagConstraints l = new GridBagConstraints();
		logPanel.setBackground(Blank);
		add(logPanel);

		// Title for the log panel
		lblLogTitle.setText("ACTIVITY LOG");
		lblLogTitle.setFont(new Font("Bahnschrift", Font.BOLD, 50));
		lblLogTitle.setHorizontalAlignment(SwingConstants.CENTER);
		l.gridx = 0;
		l.gridy = 0;
		l.gridwidth = 3;
		l.gridheight = 1;
		l.insets = new Insets(3, 5, 3, 5);
		logPanel.add(lblLogTitle, l);

		// Text Area for text log
		txtAreaLog.setFont(new Font("Consolas", Font.PLAIN, 10));
		Border border = BorderFactory.createLineBorder(Color.BLACK, 1);
		txtAreaLog.setPreferredSize(new Dimension(500,2500));
		txtAreaLog.setBorder(border);
		txtAreaScroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		txtAreaScroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		txtAreaScroll.getViewport().setBackground(Color.white);
		txtAreaScroll.getViewport().add(txtAreaLog);
		txtAreaScroll.setPreferredSize(new Dimension(600,150));
		l.gridx = 0;
		l.gridy = 1;
		l.gridwidth = 3;
		l.gridheight = 5;
		l.insets = new Insets(3, 5, 3, 5);
		logPanel.add(txtAreaScroll,l);

		btnLogExport.setText("Export Log");
		btnLogExport.setFont(new Font("Bahnschrift", Font.PLAIN, 20));
		l.gridx = 2;
		l.gridy = 7;
		l.gridwidth = 1;
		l.gridheight = 1;
		logPanel.add(btnLogExport,l);
		btnLogExport.addActionListener(e -> {
			String outputText = txtAreaLog.getText();

			try {
				LocalDateTime now = LocalDateTime.now();
				String fname = ("Logfile"+ydm.format(now)+".txt");
				File file = new File(fname);

				if (!file.exists()) {
					file.createNewFile();
				}
                FileWriter fw = new FileWriter(file.getAbsoluteFile());
                BufferedWriter bw = new BufferedWriter(fw);
                bw.write(outputText);
                bw.close();

			} catch (IOException fwe) {
                fwe.printStackTrace();
			}
			GUI.this.revalidate();
		}
		);
	}

	public static void main(String[] args) throws Exception {
		SwingUtilities.invokeAndWait(GUI::new);
	}
}
