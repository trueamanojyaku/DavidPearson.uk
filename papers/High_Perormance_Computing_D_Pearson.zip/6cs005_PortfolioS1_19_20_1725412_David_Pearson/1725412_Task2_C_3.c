//David Pearson 1725412

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <crypt.h>
#include <unistd.h>
#include <time.h>

/******************************************************************************
  Demonstrates how to crack an encrypted password using a simple
  "brute force" algorithm. Works on passwords that consist only of 2 uppercase
  letters and a 2 digit integer.

  Compile with:
    cc -o CrackAZ99 CrackAZ99.c -lcrypt

  If you want to analyse the output then use the redirection operator to send
  output to a file that you can view using an editor or the less utility:
    ./CrackAZ99 > output.txt

  Dr Kevan Buckley, University of Wolverhampton, 2018 Modified by Dr. Ali Safaa 2019
******************************************************************************/

int count=0;     // A counter used to track the number of combinations explored so far
int time_difference(struct timespec *start,
                    struct timespec *finish,
                    long long int *difference);
/**
 Required by lack of standard function in C.   
*/

void substr(char *dest, char *src, int start, int length){
  memcpy(dest, src + start, length);
  *(dest + length) = '\0';
}

/**
 This function can crack the kind of password explained above. All combinations
 that are tried are displayed and when the password is found, #, is put at the 
 start of the line. Note that one of the most time consuming operations that 
 it performs is the output of intermediate results, so performance experiments 
 for this kind of program should not include this. i.e. comment out the printfs.
*/

void crack(char *salt_and_encrypted){
  int x, y, z, u;     // Loop counters
  char salt[7];    // String used in hashing the password. Need space for \0 // incase you have modified the salt value, then should modifiy the number accordingly
  char plain[7];   // The combination of letters currently being checked // Please modifiy the number when you enlarge the encrypted password.
  char *enc;       // Pointer to the encrypted password

  substr(salt, salt_and_encrypted, 0, 6);

  for(x='A'; x<='Z'; x++){
    for(y='A'; y<='Z'; y++){
        for(u='A'; u<='Z'; u++){
            for(z=0; z<=99; z++){
                sprintf(plain, "%c%c%c%02d", x, y, u, z); 
                enc = (char *) crypt(plain, salt);
                count++;
                if(strcmp(salt_and_encrypted, enc) == 0){
                printf("#%-8d%s %s\n", count, plain, enc);
                return;	//uncomment this line if you want to speed-up the running time, program will find you the cracked password only without exploring all possibilites
                } 
            }
        }
    }
  }
}

int main(int argc, char *argv[]){
  long long int totTimeA = 0;
  for (int x = 0; x < 10; x++){
    struct timespec start,finish;
    long long int time_elapsed;
    clock_gettime(CLOCK_MONOTONIC, &start); 
    //HPC19
    //crack("$6$AS$1mYI1AoWnumQr1TU5VoPouGGT0IGe4jKnKYY6SS7o1pbKWAJz.19AXQqRQHgH9Hwp3Zgy.MsRuZj/bHdvcNS41");
    //ABC12
    crack("$6$AS$.Lb98VbQhR0UpKS47MHfBeBfaUv2xOVdxq5melSrsQmrwf.zwvsHJXQrWnyO62J.fsiKymRLZ9vOXs2nwl4L6.");
    		//Copy and Paste your ecrypted password here using EncryptShA512 program
    clock_gettime(CLOCK_MONOTONIC, &finish); 
    time_difference(&start, &finish, &time_elapsed);
    totTimeA += time_elapsed;
    printf("\tTime taken to complete run %d was = %0.2lf seconds  \n",x+1,(time_elapsed/1.0e9));
    //printf("%d solutions explored\n", count);
    count = 0;
  }
  printf("\tThe average time taken to complete was = %0.2lf seconds  \n",(totTimeA/1.0e9)/10);
    

}


//function for time differnce
int time_difference(struct timespec *start,
                    struct timespec *finish,
                    long long int *difference){

long long int ds = finish->tv_sec - start->tv_sec;
long long int dn = finish->tv_nsec - start->tv_nsec;

if(dn < 0){
    ds--;
    dn += 1000000000;
    }
    *difference = ds * 1000000000 + dn;
    return !(*difference > 0);
}
